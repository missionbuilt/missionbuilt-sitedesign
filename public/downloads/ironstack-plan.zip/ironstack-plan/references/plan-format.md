# The `.ironstack` plan file, version 1

A plan file is JSON in a file named `<plan name>.ironstack`. The IronStack iPhone app opens it with one tap (Mail, Messages, AirDrop, Files) onto a preview, and on "Add" the workouts go on the phone's Workouts shelf. **An import writes workouts, never a session.** Nothing reaches the training log until a set is logged.

`scripts/check_plan.py` refuses exactly what the app's reader refuses, with the same ceilings.

## Top level

| key | type | required | meaning |
|---|---|---|---|
| `ironstack` | integer | yes | Always `1`. Anything else is refused. |
| `name` | string | no | The program's name, e.g. "Shaw Elite, block 2". Offered as the app's program name ("Make it my program"). |
| `days` | integer 1–7 | no | Training days in the program's week. Offered with the name. |
| `notes` | string | no | Shown at the top of the preview. **Put the short caveat here.** |
| `workouts` | array, 1–40 | yes | The workouts, in program order. |

## A workout

| key | type | required | meaning |
|---|---|---|---|
| `name` | string | yes | What the lifter sees on Today: "Heavy lower", "Day 2: bench". |
| `day` | integer 1–7 | no | The program day this is. On that day Today offers it first, one tap to start. A file's workout **replaces** a workout already on the phone with the same day; the preview says which. |
| `notes` | string | no | Shown on the workout's page. |
| `lifts` | array, 1–30 | yes | In the order they are done. The same lift may appear twice (a back-off block later). |

## A lift

| key | type | required | meaning |
|---|---|---|---|
| `name` | string | yes | The lift. Use a name from `lifts.md` whenever one fits: it joins the lifter's history. A name the list lacks is kept as written and marked "new name", never refused. |
| `category` | string | no | `prep`, `main`, `accessory`, `conditioning` or `cooldown`. Left out, the app uses the lifter's own history for that lift, else `main`. |
| `gear` | array of strings | no | What is on the bar or the body for every set: ids from `equipment.md` (`cloth-belt`, `knee-sleeves`, `chains`). Unknown ones come in as new names. |
| `pace` | string or integer | no | A rolling clock (EMOM style): `"E3:00"`, `"E90"`, `"EMOM"`, `"E2MOM"`, or seconds. 15 s to 30 min. |
| `rest` | string or integer | no | A rest clock between sets: `"2:00"`, or seconds. 15 s to 30 min. A lift can carry pace, rest, both or neither. |
| `note` | string | no | A cue, kept on the plan. |
| `sets` | array, 0–20 | no | The sets it asks for. Left out: "do this lift", sets left to the day. |

## A set

| key | type | required | meaning |
|---|---|---|---|
| `reps` | integer 1–500 | yes | Reps, or seconds / feet / walks with `unit`. |
| `type` | string | no | `prep` (a warm-up set), `working` (default), `backoff`, `amrap`, `drop`, `cluster`: Mission Built schema 0.13's set types. `warmup`, 0.12's word for `prep`, is still read as `prep` until 2026-11-30 and the checker warns on it; write `prep`. |
| `rpe` | number 1–10 | no | The effort the plan asks for. |
| `weight_lb` | number 0–2000 | no | **Usually leave it out.** The app fills the weight from last time on that lift. Only write one when the program states it in pounds. Never convert a percentage into a weight: the app has the lifter's numbers and you do not. |
| `unit` | string | no | `reps` (default), `seconds`, `meters`, `feet`, `yards`, `calories`, `walks`. |
| `note` | string | no | Kept on the plan. |

## Refused

The app shows one line and changes nothing when:

- the file is not JSON, or `ironstack` is missing or not `1`;
- there are no workouts, or more than 40;
- `days` or a workout's `day` is outside 1–7;
- a workout has no name, no lifts, or more than 30 lifts;
- a lift has no name, an unknown `category`, a `pace` or `rest` it can't read or outside 15 s to 30 min, or more than 20 sets;
- a set's `reps` is missing or outside 1–500, its `type` or `unit` is unknown, its `rpe` is outside 1–10, or its `weight_lb` is outside 0–2000.

Warnings (the checker prints them; the app takes the file): a lift name or gear the lists don't know, two workouts on the same day, a day past `days`.
