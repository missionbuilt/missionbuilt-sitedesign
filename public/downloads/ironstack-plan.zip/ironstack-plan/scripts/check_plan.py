#!/usr/bin/env python3
"""Check a .ironstack plan file the way the IronStack app will.

Standard library only. Refuses exactly what the app's plan-file reader
refuses, with the same ceilings, so a file this prints OK for is a file the phone takes.
It also warns (never refuses) about lift names the app's lift list does not know and gear
it cannot resolve: the app keeps those as said and marks them new, which works, but a
typo there costs the lifter a history that never joins up.

    python3 check_plan.py "Shaw Elite block 2.ironstack"

Exit status 0 when the app would take the file, 1 when it would refuse it.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

VERSION = 1
MAX_WORKOUTS = 40
MAX_LIFTS = 30
MAX_SETS = 20
MAX_REPS = 500
MAX_WEIGHT_LB = 2000.0
PACE_MIN, PACE_MAX = 15, 1800
CATEGORIES = {"prep", "main", "accessory", "conditioning", "cooldown"}
# Mission Built schema 0.13's set types. A warm-up set is `prep`.
SET_TYPES = {"prep", "working", "backoff", "amrap", "drop", "cluster"}
# 0.12 spelled it `warmup`. Plan format 1 carries no schema version, so the app reads every
# plan file as written before 0.13 and translates the old word; this warns with the
# Mission Built Schema validator's words for the same case. Sunset 2026-11-30: after it
# the app's 0.12 reader is gone, and so is this.
LEGACY_SET_TYPES = {"warmup": "prep"}
SUNSET_0_12 = "2026-11-30"
UNITS = {"reps", "seconds", "meters", "feet", "yards", "calories", "walks"}

HERE = Path(__file__).resolve().parent
REFS = HERE.parent / "references"


class Refused(Exception):
    pass


def seconds(raw) -> int | None:
    """E3:00 and 3:00 are 180, E90 is 90, EMOM is 60, E2MOM is 120, 150 is 150."""
    if isinstance(raw, bool):
        return None
    if isinstance(raw, int):
        return raw
    if not isinstance(raw, str):
        return None
    s = raw.strip().upper()
    if s == "EMOM":
        return 60
    m = re.fullmatch(r"E(\d+)MOM", s)
    if m:
        return int(m.group(1)) * 60
    if s.startswith("E"):
        s = s[1:]
    if s.endswith("S"):
        s = s[:-1]
    m = re.fullmatch(r"(\d+):(\d{1,2})", s)
    if m and int(m.group(2)) < 60:
        return int(m.group(1)) * 60 + int(m.group(2))
    if re.fullmatch(r"\d+", s):
        return int(s)
    return None


def text(value) -> str | None:
    if not isinstance(value, str):
        return None
    value = value.strip()
    return value or None


def number(value) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def load_lists():
    lifts, gear = set(), set()
    try:
        ex = json.loads((REFS / "exercises.json").read_text())
        lifts = {n.lower() for n in ex.get("canonical", [])} | {a.lower() for a in ex.get("aliases", {})}
    except (OSError, ValueError):
        pass
    try:
        eq = json.loads((REFS / "equipment.json").read_text())
        for piece in eq.get("equipment", []):
            gear.add(piece["id"].lower())
            gear.add(piece["name"].lower())
        gear |= {a.lower() for a in eq.get("aliases", {})}
    except (OSError, ValueError, KeyError):
        pass
    return lifts, gear


def check(doc) -> tuple[list[str], list[str]]:
    """Returns (report lines, warnings). Raises Refused with the app's reason."""
    if not isinstance(doc, dict):
        raise Refused("This isn't a plan file Ironstack can read. It needs to be the JSON a plan file holds.")
    if "ironstack" not in doc:
        raise Refused('This file doesn\'t say it\'s an Ironstack plan (no "ironstack": 1 at the top).')
    if doc["ironstack"] != VERSION:
        raise Refused("This plan was written for a newer Ironstack. Update the app and open it again.")
    workouts = doc.get("workouts") or []
    if not isinstance(workouts, list) or not workouts:
        raise Refused("The file has no workouts in it.")
    if len(workouts) > MAX_WORKOUTS:
        raise Refused(f"More than {MAX_WORKOUTS} workouts in one file. Split it up.")
    days = doc.get("days")
    if days is not None and not (isinstance(days, int) and 1 <= days <= 7):
        raise Refused('"days" has to be between 1 and 7.')

    known_lifts, known_gear = load_lists()
    report, warnings = [], []
    seen_days = {}
    for w_i, w in enumerate(workouts):
        if not isinstance(w, dict) or not text(w.get("name")):
            raise Refused(f"Workout {w_i + 1} has no name.")
        name = text(w["name"])
        day = w.get("day")
        if day is not None and not (isinstance(day, int) and 1 <= day <= 7):
            raise Refused(f"{name}: the day has to be between 1 and 7.")
        if day is not None:
            if day in seen_days:
                warnings.append(f"Day {day} is used by both {seen_days[day]} and {name}; the app offers the first.")
            seen_days[day] = name
            if isinstance(days, int) and day > days:
                warnings.append(f"{name} is day {day} but the program has {days} days a week.")
        lifts = w.get("lifts") or []
        if not isinstance(lifts, list) or not lifts:
            raise Refused(f"{name} has no lifts.")
        if len(lifts) > MAX_LIFTS:
            raise Refused(f"{name} has more than {MAX_LIFTS} lifts.")
        head = f"Day {day} · {name}" if day is not None else name
        report.append(f"{head}  ({len(lifts)} lift{'s' if len(lifts) != 1 else ''})")
        for l_i, lift in enumerate(lifts):
            report.append("  " + check_lift(lift, l_i, name, known_lifts, known_gear, warnings))
    return report, warnings


def check_lift(lift, index, workout, known_lifts, known_gear, warnings) -> str:
    if not isinstance(lift, dict) or not text(lift.get("name")):
        raise Refused(f"{workout}: lift {index + 1} has no name.")
    name = text(lift["name"])
    here = f"{workout}, {name}"
    if known_lifts and name.lower() not in known_lifts:
        warnings.append(f"{here}: not in the lift list. The app keeps it as said and marks it new; "
                        f"check the spelling against references/lifts.md.")
    cat = text(lift.get("category"))
    if cat is not None and cat.lower() not in CATEGORIES:
        raise Refused(f'{here}: "{lift.get("category")}" isn\'t a category. Use prep, main, accessory, conditioning or cooldown.')
    parts = []
    for key, label, example in (("pace", "pace", "E3:00"), ("rest", "rest", "2:00")):
        if lift.get(key) is None:
            continue
        s = seconds(lift[key])
        if s is None or not (PACE_MIN <= s <= PACE_MAX):
            raise Refused(f'{here}: can\'t read the {label} "{lift[key]}". Write it like {example}.')
        parts.append(f"E{s // 60}:{s % 60:02d}" if key == "pace" else f"{s // 60}:{s % 60:02d} rest")
    gear = lift.get("gear") or []
    if not isinstance(gear, list) or not all(isinstance(g, str) for g in gear):
        raise Refused(f"{here}: gear has to be a list of names or ids.")
    for g in gear:
        if known_gear and g.strip() and g.strip().lower() not in known_gear:
            warnings.append(f'{here}: gear "{g}" isn\'t in the gear list; it will come in as a new name.')
    sets = lift.get("sets") or []
    if not isinstance(sets, list):
        raise Refused(f"{here}: sets has to be a list.")
    if len(sets) > MAX_SETS:
        raise Refused(f"{here} has more than {MAX_SETS} sets.")
    lines = []
    for s_i, st in enumerate(sets):
        at = f"{here}, set {s_i + 1}"
        if not isinstance(st, dict):
            raise Refused(f"{at}: reps have to be between 1 and {MAX_REPS}.")
        reps = st.get("reps")
        if not (isinstance(reps, int) and not isinstance(reps, bool) and 1 <= reps <= MAX_REPS):
            raise Refused(f"{at}: reps have to be between 1 and {MAX_REPS}.")
        kind = st.get("type")
        if kind in LEGACY_SET_TYPES:
            new = LEGACY_SET_TYPES[kind]
            warnings.append(f"{at}: set.type: `{kind}` was renamed `{new}` in 0.13; a 0.13 reader "
                            f"translates it (until {SUNSET_0_12}). Write `{new}`.")
            kind = new
        if kind is not None and kind not in SET_TYPES:
            raise Refused(f'{at}: "{st["type"]}" isn\'t a set type.')
        if st.get("unit") is not None and st["unit"] not in UNITS:
            raise Refused(f'{at}: "{st["unit"]}" isn\'t a unit.')
        rpe = st.get("rpe")
        if rpe is not None and not (number(rpe) and 1 <= rpe <= 10):
            raise Refused(f"{at}: RPE has to be between 1 and 10.")
        w = st.get("weight_lb")
        if w is not None and not (number(w) and 0 <= w <= MAX_WEIGHT_LB):
            raise Refused(f"{at}: a weight over {int(MAX_WEIGHT_LB)} lb isn't one anybody lifts.")
        line = (f"{w:g}" if w is not None else "—") + f"x{reps}"
        if rpe is not None:
            line += f" @{rpe:g}"
        if kind == "prep":
            line = "w " + line
        lines.append(line)
    if lines:
        parts.insert(0, ", ".join(lines))
    if gear:
        parts.append(" ".join("@" + g for g in gear))
    return name + ("  " + " · ".join(parts) if parts else "")


def main(argv) -> int:
    if len(argv) != 2:
        print(__doc__.strip().splitlines()[0])
        print('usage: python3 check_plan.py "<plan name>.ironstack"')
        return 2
    path = Path(argv[1])
    try:
        doc = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        print("REFUSED: This isn't a plan file Ironstack can read. It needs to be the JSON a plan file holds.")
        return 1
    try:
        report, warnings = check(doc)
    except Refused as r:
        print(f"REFUSED: {r}")
        return 1
    if doc.get("name") or doc.get("days"):
        bits = [b for b in (doc.get("name"), f"{doc['days']} days a week" if doc.get("days") else None) if b]
        print("Program: " + ", ".join(bits))
    print("\n".join(report))
    for w in warnings:
        print("WARNING: " + w)
    print("OK" + (f" ({len(warnings)} warning{'s' if len(warnings) != 1 else ''})" if warnings else ""))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
