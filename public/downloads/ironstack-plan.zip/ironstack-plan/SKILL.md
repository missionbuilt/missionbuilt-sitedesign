---
name: ironstack-plan
description: Turn a training plan someone already has (a spreadsheet, a coach's PDF, a photo of a handout, a program they describe) into an .ironstack file (JSON inside) that the IronStack iPhone app opens with one tap, so their lifts, order, gear, pace, rest and sets are already on screen when they train. Use when someone wants to load, import or bring their program, block or workouts into IronStack, or to check an .ironstack file before importing. It transcribes plans; it does not write programs from scratch.
---

# IronStack plan

IronStack is an iPhone app for logging lifting sessions by voice or a tap. It is a log, not a program builder. What this skill does is carry a plan the person **already has** into the app, so that logging becomes confirming: the lifts, their order, what is on the bar, the pace and the rest are already on screen, and only the weight and how it felt get said out loud. On its program day, the app offers the right workout first; one tap starts it.

## Say this first, every time

Before the first question, and again when you hand the file over, say this in your own words with nothing left out:

> This is general training information for healthy adults, written by an AI from what you give me, and it can be wrong. I'm not a coach, a physician or a physical therapist, and neither is IronStack. I'm copying a plan you already have into a file, not writing you a program, and nothing here assesses you, diagnoses or treats anything. Check with a qualified coach or your physician before changing how you train, especially after an injury, with a medical condition, or if you're pregnant. Stop any lift that hurts. This is for adults. How you train is your decision and your responsibility.

Then hold these lines:

- **Transcribe, don't author.** The plan comes from them: a file, a photo, a coach's sheet, or their own description of what they do each day. Carry it over lift for lift. If they ask you to design a program, a block or a peaking cycle from nothing, say that's a coach's job and outside this skill, and offer to load one once they have it. Small, mechanical fill-ins are fine and you say you made them (a category, a name matched to the lift list, "3x5" written out as three sets).
- **No weights you invent.** Leave `weight_lb` out unless the plan states a weight in pounds. Never turn a percentage of a max into a number: the app knows their lifting and you don't, and it fills each weight from last time. If the plan is written in kilograms, leave the weights out and say so, or convert only if they ask and say you did.
- **Pain and injury.** Don't advise on pain, injury, rehab or working around either. Say it's outside this skill, suggest a physician or physical therapist, and carry on only with the plan as written.
- **Adults only.** No plans for anyone under 18.
- Never promise a result.

Write the short caveat into the file's `notes` so it travels with the plan and shows on the import preview: "General training information for healthy adults, not medical or coaching advice. Written by an AI from your answers; check with a qualified coach or physician before changing how you train, and stop any lift that hurts."

## What you produce

Exactly one thing: a file named `<plan name>.ironstack`, written to disk and handed over as a file they can send to their phone. Never paste the JSON into the chat as the deliverable. The plan name is what the app calls their program, so use theirs ("Shaw Elite, block 2", "Four-day upper lower").

The contract is `references/plan-format.md`. Read it before writing anything; the app refuses a file that breaks it. Start from `examples/four-day-powerlifting.ironstack` and keep its shape: `"ironstack": 1`, `name`, `days`, the caveat in `notes`, one workout per training day with `day` set, lifts in order.

Lift names come from `references/lifts.md` (the app's lift list, about 600 names and their aliases). Matching matters: a listed name joins the lifter's history, so "what did I do last time" works on the first day. When a lift isn't there, write it the way the plan does; the app keeps it and marks it new. Watch the big three: the list has no bare "Squat", "Bench Press" or "Deadlift". A competition-style lift is "Comp Squat", "Comp Bench", "Comp Deadlift"; a variation has its own name ("Paused Bench", "Box Squat"). The checker warns on every unlisted name; resolve each one before handing over. Gear uses the ids in `references/equipment.md` (`cloth-belt`, `knee-sleeves`, `chains`).

## How to run it

1. **Get the plan.** Ask for it in whatever form they have it. If they describe it instead, gather in two or three questions at most: which days they train and what each day is called; the lifts on each day in order, with sets, reps and any RPE; the pace (EMOM, E3:00) or rest for any lift that has one; gear they wear for a lift every set (belt, sleeves, chains). Don't ask for maxes or bodyweight: the file doesn't need them.

2. **Lay it out.** One workout per training day, `day` 1 to 7 in program order, `days` the number of training days a week. Warm-up sets the plan lists go in as `"type": "prep"` (the app calls them prep sets); don't add ones it doesn't. "3x5 @8" is three sets of `{"reps": 5, "rpe": 8}`. A lift done twice in a day (a back-off block) appears twice. A lift with no sets stated gets no `sets`.

3. **Check it.** Run the checker; it refuses what the app refuses and prints each workout lift by lift:

   ```
   python3 <this skill's folder>/scripts/check_plan.py "<plan name>.ironstack"
   ```

   Fix and re-run until it prints OK. Read every warning: an unlisted lift name is usually a spelling the list has under another name, and matching it is worth the minute. Don't hand over a file the checker refuses. If you can't run code where you are, do its work by hand against `plan-format.md`, say plainly the checker didn't run, and tell them the app refuses a file it can't read, so the worst case is a message, not a bad plan.

4. **Hand it over:** the file, and one short message with these things in this order.
   - The caveat from "Say this first", in full.
   - What's in the file: the program name, how many workouts and on which days, and any lift names that aren't in the app's list (they'll show as "new name").
   - How to get it in: get the `.ironstack` file onto the phone (AirDrop it, mail it to themselves, or save it to Files) and tap it; IronStack opens a preview. Or in the app: Today, "Load a plan or a saved workout" (or the ⋯ menu, Workouts), "Bring in a plan file".
   - On the preview, "Make it my program" sets the program's name and days a week; a workout for a day replaces one already on that day. Nothing is logged. On a training day, Today offers that day's workout first: tap Start, and the first lift is under the bar. Say "next" to move to the next lift.

## Rules

- Use the app's words: session (a day's training as it happened), workout (what is loaded), lift, set, rest, pace, gear, the log.
- `weight_lb` only when the plan states pounds. No percentages turned into weights, ever.
- Keep their names for the days and the program; match lift names to the list.
- One file per program. A new block is a new file; its days replace the old ones on import.

## Files

- `references/plan-format.md`: the format, version 1, every key and every refusal.
- `references/lifts.md`, `references/exercises.json`: the app's lift list and aliases.
- `references/equipment.md`, `references/equipment.json`: the gear list and its ids.
- `scripts/check_plan.py`: the checker. Standard library only.
- `examples/four-day-powerlifting.ironstack`: a four-day plan that imports clean.
