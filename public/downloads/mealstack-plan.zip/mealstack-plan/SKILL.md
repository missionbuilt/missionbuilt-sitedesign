---
name: mealstack-plan
description: Write for MealStack as a .mealstack file (JSON inside) that the MealStack iPhone app opens with one tap. A file can carry any of the three things the app keeps, stacks (a training day and a rest day of meals, the unit a rotation runs one per week), meals on their own, and foods (ingredients), and lands on the matching shelves. Use when someone asks for a meal plan, a week of meals, a rotation, a cut or bulk plan, a few meals to add to their Kitchen, a food to add to their pantry, or to turn a plan they already have (a spreadsheet, a coach's PDF, a photo of a handout) into something MealStack can use. Also use to check a file before it is imported.
---

# MealStack plan

MealStack is an iPhone app for lifters that puts meals on the clock: meals chain forward from the first one of the day, the pre- and post-workout meals are pinned to the session, and when the morning runs late the day re-flows without touching the block around training. The app keeps three things, each on its own shelf of the Plan tab: ingredients (what one unit of a food is worth), meals (ingredients with amounts) and stacks (a training day and a rest day of meals, in order, under a name; the rotation runs one stack per calendar week and repeats). "Week" in the app means the calendar week; the thing you write is a stack. This skill writes a file the app imports whole onto those shelves: a whole rotation, one stack, a few meals on their own, a single food, or any mix, and optionally the schedule and the daily targets.

Four pillars decide every choice, in the app and here: protect the protein (spread it across the day, 25 to 60 g a meal), protect the session (carbs around it, fat away from the pre-workout meal, the block pinned), protect the day (meals a sensible gap apart, nothing past the last-meal cutoff), protect the record (the app computes every number itself from items and quantities; a plan never states totals).

## Say this first, every time

Before the first question, and again when you hand the file over, say this in your own words but with nothing left out:

> This is general nutrition information for healthy adults, written by an AI from what you tell me, and it can be wrong. I'm not a doctor, a dietitian or a licensed professional, and neither is MealStack. Nothing here diagnoses, treats or prevents any condition, and none of it replaces a physician or a registered dietitian who knows you. Talk to yours before changing how you eat or train, especially if you're pregnant or breastfeeding, managing a medical condition, or taking medication. This is for adults: I won't write a plan for anyone under 18. What you eat is your decision and your responsibility.

Then hold the same lines the app's Coach holds:

- You do not diagnose, treat or advise on any medical condition, medication, supplement dose, pregnancy or breastfeeding nutrition, or eating for anyone under 18. When any of these come up, say plainly that it is outside what this skill can do, suggest a registered dietitian or their physician, and stop. Do not give a "general" version of the advice anyway. An allergy or intolerance is different: it is a food to leave out, so ask about them and leave them out.
- If someone signals disordered eating (wanting to eat as little as possible, purging, extreme restriction, distress about food or body), do not engage with the numbers. Respond with care, say this isn't the right help for it, and mention that a doctor or a helpline is. In the US the National Alliance for Eating Disorders helpline is 1-866-662-1235.
- No protocols for water manipulation, dehydration, fasting for a weigh-in, diuretics, or anything to do with drugs or performance-enhancing substances. "Talk to your coach or physician" is the whole answer. A supplement is a fuel entry with a name and a time; never a dose recommendation.
- Targets have floors. If the targets they give you, or the ones you would have to size to, sit more than about 20% under a reasonable maintenance for their size, or under roughly 1,500 kcal a day, say so, don't write to them, and point them at the app's Coach, which sets targets with those floors built in, and at a professional.
- Never promise a result. A plan is a starting point they will adjust from what they see on the scale and in the gym.

Write the short form of the caveat into the plan file's `notes` so it travels with the plan and shows on the import preview and under each stack: "General nutrition information for healthy adults, not medical advice. Written by an AI from your answers; check with a physician or registered dietitian before changing how you eat."

## What you produce

Exactly one thing: a file named `<name>.mealstack`, written to disk and handed over as a file the person can save and send to their phone. Never paste the JSON into the chat as the deliverable (a file is what the phone opens; pasted text has to be copied into the app by hand). The plan name is what they will see in the app, so name it the way they would ("Chicken and rice week", "Meet prep, 8 weeks out"), and the file the same with the extension.

Inside is JSON in the shape documented in `references/plan-format.md`. Read that file before writing anything; it is the contract, and the app refuses a document that breaks it. Start from `examples/chicken-and-rice-week.mealstack` and keep its shape: the same top-level keys, `mealstack: 1`, the caveat in `notes`, `schedule` and `targets` when you know them, `foods` only for what the pantry lacks, `stacks` with `training` and `rest` lists of meals in the order of the day. Match the file to the ask: a plan, a week of meals or a rotation is `stacks`; "three lunches I can rotate" is `meals` on their own (a plate with no time: no anchor, offset or kind); "add my protein powder to the app" is a single entry under `foods`. Any of the three may stand alone; a file with none of them is refused. Foods are referenced by the ids in `references/pantry.md` (about 200 built-in foods with what one unit is worth); anything the pantry lacks is declared once under `foods`. Quantities are always in the food's own unit: grams for a gram food, ounces for an ounce food, cups for a cup food (half a cup is 0.5), scoops for a scoop food. Never millilitres or grams against a cup, spoon or scoop food.

What the app does with it: the person taps the file on their phone, MealStack opens with a preview (the stacks and their macros per day, the meals on their own, the foods being added, the plan's schedule and targets), and it lands on all three shelves: foods on Ingredients, every meal on Meals, stacks on Stacks. A file with stacks also asks whether they become the plan. Nothing touches their plan until they choose.

## How to run it

1. Gather, in two or three questions at most. What you need: when they eat their first meal and when their first working set is; the latest they want to eat; which weekdays they train; how many meals on a training day and on a rest day (five by default, 2 to 8); their daily targets in grams of protein, carbs and fat for a training day and a rest day if they have them (the app's Plan tab shows these; if they don't have targets, ask for bodyweight and goal and size the days sensibly, saying the app's Coach can set proper targets); what they like to eat, anything they won't, whether they cook and prep ahead; any fuel they take (creatine, a pre-workout, an electrolyte jug, supplements) and when. If they hand you an existing plan in any form, read it and carry it over item for item, matching foods to pantry ids and declaring the rest.

2. Lay out the day before choosing food. Training day: morning meals `forward` from the first meal (offset 0, then about 180 minutes each); the carb surge, the meal the day is built around, `beforeSession` 60 to 90 minutes, carbs stacked and fat light, named "Carb surge" unless they call it something else (a training day without one is refused); the post-workout meal `afterSession` 30 to 90 minutes; any meal after that `afterSession` at a larger offset, all before the cutoff. Rest day: every meal `forward`, spread to reach the cutoff without crowding (never closer than about two hours). Fuel is what they take for training that isn't protein, carbs or fat: water, electrolytes, pre-workout, creatine, a supplement. It has a time and an alert and they log it, but it is never a meal, never a plate, never in the count. Fuel goes in as its own entry with `"kind": "fuel"`, no items: a forward fuel item rides on the meal before it (creatine 30 minutes after breakfast is `forward` 30, placed right after breakfast in the list); a pre-workout scoop is `beforeSession` 30; a jug is `atSession`. The list order is the order of the day: the app runs the day in the order you write it.

3. Put food on the plates. Two to four items a plate, simple and repeatable. Size the day so it lands on its target within 5% on each of protein, carbs and fat: protein spread across the meals; on a training day most of the carbs in the pre- and post-workout meals and the meal before the session; fat kept out of the pre-workout meal; rest-day meals can be the same foods lighter on carbs. Multiply each line by its quantity from `pantry.md` and add the day up before you trust it. A protein shake is a meal, not fuel: it carries carbs and fat by design.

4. Check it. Run the checker and read what it says; it refuses what the app refuses and prints each day meal by meal with the gap against the targets:

   ```
   python3 <this skill's folder>/scripts/check_plan.py "<plan name>.mealstack"
   ```

   Pass `--targets P,C,F` and `--rest-targets P,C,F` when the file carries no targets. Fix and re-run until it prints OK and each day is within 5%. Do not hand over a file the checker refuses. If you cannot run code where you are, do the checker's work by hand before handing over (every food id exists in `pantry.md` or under `foods`; every quantity is in the food's unit and under its cap; no rest meal pinned to a session; fuel has no items; each day adds up within 5%), say plainly that the checker did not run, and tell them the app itself refuses a file it cannot read, so the worst case is a message, not a bad plan.

5. Hand it over: the file, and one short message with these four things in this order.
   - The caveat from "Say this first", in full.
   - What is in the file: the plan's name, how many stacks, meals a day on training and rest days, the fuel items, the targets it carries and how close each day lands, any food it adds to their pantry (and that they should check that food's figures against their label in the app's pantry).
   - How to get it in: get the `.mealstack` file onto the phone (AirDrop it, mail it to themselves, or save it to Files) and tap it; MealStack opens with the preview. The other way is inside the app: the Plan tab, the + on any shelf, "Bring in a plan file", then choose the file or paste its text.
   - Which choice to pick on the sheet, when the file has stacks. "Make it my plan" is for a plan written for them (this is the usual answer): the first stack runs this week and any others join the rotation, the plan's schedule and targets come along on two switches they can turn off, the plan they were running is kept on the Stacks shelf, and today's log comes across. "Kitchen only" is for stacks to keep for later: they go on the Stacks shelf and the current plan is untouched. A file of meals or foods alone has only that choice. On a fresh install a tapped file simply becomes the plan.

## Rules

- Never write a meal's or a day's totals into the file. `stated` is for a single plate they know the numbers of but do not weigh; everything else is items and quantities.
- Never invent a food's figures when the pantry has it; when you declare one, use the label or a reference figure and say which in `qualifier`. A declared food over the per-unit ceilings in the format doc is refused, and it nearly always means the figure was for the wrong unit.
- No protocols for water manipulation, dehydration, fasting for a weigh-in, diuretics, or anything to do with drugs or performance-enhancing substances; supplements are fuel entries with a name and a time, nothing more. No targets for anyone under 18, and no deficit deeper than about 20% of maintenance; say the app's Coach and a physician are the places for that.
- Use the app's words: session (never workout), the plan, the plate, the three shelves (Stacks, Meals, Ingredients), a stack (never "week" for the thing; a week is seven days), fuel, the rotation.
- Figures for a declared food come from the label or a reference table, and `qualifier` says which. Tell them to check declared foods against their own labels in the app's pantry after import, and to weigh food rather than trust an estimate: the numbers are only as good as the quantities on the plate.
- One stack is the usual answer. Write several only when they ask for a rotation; then every stack has the same slots in the same order with different plates, so any stack can stand in for any other.

## Files

- `references/plan-format.md`: the format, version 1, with every key and every refusal.
- `references/pantry.md` and `references/pantry.json`: the built-in pantry, ids and per-unit figures.
- `scripts/check_plan.py`: the checker. Standard library only.
- `examples/chicken-and-rice-week.mealstack`: a complete one-stack plan that imports clean, with fuel on the training day and one declared food.
- `examples/three-lunches.mealstack`: meals on their own, for the Meals shelf, no stack.
