#!/usr/bin/env python3
"""Check a MealStack plan file the way the app does, and say what it adds up to.

    python3 check_plan.py my-plan.mealstack
    python3 check_plan.py my-plan.mealstack --targets 230,360,63 --rest-targets 220,272,73

Exit 0 when the app would import the file. Exit 1 with one line per problem when it
would refuse it. Either way, prints each stack's training and rest day: meal by meal
with its macros, the day's total, and the gap against the targets (the file's own,
or the ones passed in). No dependencies beyond the standard library. The built-in
ingredients it knows are in references/pantry.json next to this script's folder.

Declared ingredients go under `ingredients`, or under `foods`, the spelling the 0.9
app reads. A file with both is read by `ingredients` and `foods` is ignored, the
same rule as `stacks` and `weeks`.
"""

import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
PANTRY_FILE = HERE.parent / "references" / "pantry.json"

VERSION = 1
UNITS = {"gram", "ounce", "each", "cup", "tbsp", "tsp", "scoop", "packet", "bottle"}
ANCHORS = {"forward", "beforeSession", "atSession", "afterSession"}
# Per unit, above which a declared ingredient is refused as mis-stated (kcal in one unit).
FOOD_KCAL_MAX = {"gram": 9.1, "ounce": 260, "tsp": 50, "tbsp": 140, "cup": 1000, "each": 1000,
                 "scoop": 400, "packet": 400, "bottle": 800}
# Grams of macros one unit can physically hold (a unit weighs at most this much).
FOOD_GRAMS_MAX = {"gram": 1, "ounce": 28.35, "tsp": 7.5, "tbsp": 22, "cup": 340, "scoop": 60, "packet": 60, "bottle": 600}
# The most of one ingredient a plate can hold, in its unit.
QUANTITY_MAX = {"gram": 2000, "ounce": 64, "each": 24, "cup": 8, "tbsp": 16, "tsp": 24,
                "scoop": 6, "packet": 6, "bottle": 6}
LINE_KCAL_MAX = 1500
MEAL_KCAL_MAX = 3000
ID_RE = re.compile(r"^[A-Za-z][A-Za-z0-9._-]*$")
TIME_RE = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")
# Protein per meal outside this band earns a note (the app's readout uses the same).
PROTEIN_BAND = (25, 60)


def kcal(m):
    return m["p"] * 4 + m["c"] * 4 + m["f"] * 9


def add(a, b):
    return {"p": a["p"] + b["p"], "c": a["c"] + b["c"], "f": a["f"] + b["f"]}


def is_number(v):
    # JSON true/false are ints to Python and not numbers to the app.
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def is_text(v):
    return v is None or isinstance(v, str)


def is_text_list(v):
    return v is None or (isinstance(v, list) and all(isinstance(x, str) for x in v))


def macros_ok(m):
    return isinstance(m, dict) and all(is_number(m.get(k)) and m[k] >= 0 for k in ("p", "c", "f"))


def line(m):
    return f"{round(m['p'])}P {round(m['c'])}C {round(m['f'])}F, {round(kcal(m))} kcal"


def parse_targets(text):
    if not text:
        return None
    p, c, f = (float(x) for x in text.split(","))
    return {"p": p, "c": c, "f": f}


def load_pantry():
    data = json.loads(PANTRY_FILE.read_text())
    return {f["id"]: f for f in data["foods"]}


def check(doc, pantry, targets_override=None, rest_override=None):
    errors = []
    notes = []
    if not isinstance(doc, dict):
        return ["the file is not a JSON object"], notes, []
    if not is_number(doc.get("mealstack")) or doc.get("mealstack") != VERSION:
        errors.append(f"mealstack must be {VERSION} (got {doc.get('mealstack')!r})")
    if not isinstance(doc.get("name"), str) or not doc["name"].strip():
        errors.append("name is required")
    if not is_text(doc.get("notes")):
        errors.append("notes must be text")
    notes_text = doc.get("notes") if isinstance(doc.get("notes"), str) else ""
    if "not medical advice" not in notes_text.lower():
        notes.append("notes: carry the caveat ('General nutrition information for healthy adults, not medical advice. Written by an AI from your answers; check with a physician or registered dietitian before changing how you eat.') so it shows on the import preview")

    schedule = doc.get("schedule")
    if schedule is not None:
        if not isinstance(schedule, dict):
            errors.append("schedule must be an object")
        else:
            for key in ("wake", "session", "latestMeal"):
                v = schedule.get(key)
                if v is not None and not (isinstance(v, str) and TIME_RE.match(v)):
                    errors.append(f"schedule.{key} must be HH:MM (24-hour), got {v!r}")
            days = schedule.get("trainingWeekdays")
            if days is not None and not (isinstance(days, list) and all(isinstance(d, int) and 1 <= d <= 7 for d in days)):
                errors.append("schedule.trainingWeekdays must be a list of 1 (Sunday) to 7 (Saturday)")

    targets = doc.get("targets")
    if targets is not None:
        if not isinstance(targets, dict):
            errors.append("targets must be an object")
        else:
            for key in ("training", "rest"):
                if key in targets and not macros_ok(targets[key]):
                    errors.append(f"targets.{key} must be {{p, c, f}} in grams")

    foods = dict(pantry)
    # "ingredients" is the documented key; "foods" is what the 0.9 app reads and still
    # reads. With both, "ingredients" wins and "foods" is ignored, as the app does.
    key = "ingredients" if doc.get("ingredients") is not None else "foods"
    declared = doc.get(key) or []
    if not isinstance(declared, list):
        errors.append(f"{key} must be a list")
        declared = []
    for i, f in enumerate(declared):
        tag = f"{key}[{i}]"
        if not isinstance(f, dict):
            errors.append(f"{tag}: not an object"); continue
        fid = f.get("id")
        if not isinstance(fid, str) or not ID_RE.match(fid):
            errors.append(f"{tag}: id must start with a letter and use only letters, digits, '.', '_' and '-' (got {fid!r})"); continue
        if fid in pantry:
            errors.append(f"{tag}: '{fid}' is already a built-in ingredient; reference it instead of declaring it"); continue
        if not isinstance(f.get("name"), str) or not f["name"].strip():
            errors.append(f"{tag} ({fid}): name is required")
        if not is_text(f.get("qualifier")):
            errors.append(f"{tag} ({fid}): qualifier must be text")
        unit = f.get("unit")
        if unit not in UNITS:
            errors.append(f"{tag} ({fid}): unit must be one of {sorted(UNITS)}"); continue
        per = f.get("per")
        if not macros_ok(per):
            errors.append(f"{tag} ({fid}): per must be {{p, c, f}} grams in one {unit}"); continue
        if kcal(per) > FOOD_KCAL_MAX[unit]:
            errors.append(f"{tag} ({fid}): {round(kcal(per))} kcal in one {unit} is over the {FOOD_KCAL_MAX[unit]} ceiling; the figure is for the wrong unit")
        elif unit in FOOD_GRAMS_MAX and per["p"] + per["c"] + per["f"] > FOOD_GRAMS_MAX[unit]:
            errors.append(f"{tag} ({fid}): {round(per['p'] + per['c'] + per['f'])} g of macros in one {unit}, which weighs at most {FOOD_GRAMS_MAX[unit]} g; the figure is for the wrong unit")
        foods[fid] = {"id": fid, "name": f["name"], "unit": unit, "per": per}

    report = []
    # "stacks" is the key; "weeks" is the older spelling and still reads.
    weeks = doc.get("stacks") if doc.get("stacks") is not None else (doc.get("weeks") or [])
    shelf_meals = doc.get("meals") or []
    if not isinstance(weeks, list):
        errors.append("stacks must be a list"); weeks = []
    if not isinstance(shelf_meals, list):
        errors.append("meals must be a list"); shelf_meals = []
    if not weeks and not shelf_meals and not declared:
        errors.append("the file has no stacks, no meals and no ingredients: nothing to import")
        return errors, notes, report

    # Meals on their own: the same plate, no time.
    if shelf_meals:
        rows = []
        for i, meal in enumerate(shelf_meals):
            mtag = f"meal {i + 1}"
            if not isinstance(meal, dict):
                errors.append(f"{mtag}: not an object"); continue
            name = meal.get("name") if isinstance(meal.get("name"), str) and meal["name"].strip() else None
            if not name:
                errors.append(f"{mtag}: name is required"); name = mtag
            for key in ("anchor", "offsetMinutes", "kind"):
                if key in meal:
                    errors.append(f"{mtag} ({name}): a meal on its own has no {key}; that belongs to a meal inside a stack")
            text_problems(meal, f"{mtag} ({name})", errors)
            m = plate(meal, foods, f"{mtag} ({name})", errors, notes)
            if m is None:
                continue
            rows.append((name, "shelf", m))
        if rows:
            report.append({"name": "Meals for the shelf", "days": [{"day": "shelf", "rows": rows, "total": None, "count": len(rows), "target": None}]})

    for w, week in enumerate(weeks):
        wtag = f"stack {w + 1}"
        if not isinstance(week, dict):
            errors.append(f"{wtag}: not an object"); continue
        wname = week.get("name") if isinstance(week.get("name"), str) else f"Stack {w + 1}"
        # The app reads a stack only whole: a name, a training list and a rest list,
        # each present even when empty.
        if not isinstance(week.get("name"), str):
            errors.append(f"{wtag}: name is required (text; it may be empty)")
        if not is_text(week.get("note")):
            errors.append(f"{wtag} ({wname}): note must be text")
        missing = [k for k in ("training", "rest") if k not in week or week[k] is None]
        if missing:
            errors.append(f"{wtag} ({wname}): {' and '.join(missing)} {'is' if len(missing) == 1 else 'are'} required; write [] for a day with no meals"); continue
        training = week["training"]
        rest = week["rest"]
        if not isinstance(training, list) or not isinstance(rest, list):
            errors.append(f"{wtag} ({wname}): training and rest must be lists"); continue
        if not training and not rest:
            errors.append(f"{wtag} ({wname}): a stack needs at least one meal"); continue
        if training and not any(isinstance(m, dict) and m.get("anchor") == "beforeSession" and m.get("kind", "meal") != "fuel" for m in training):
            errors.append(f"{wtag} ({wname}): the training day has no meal pinned before the session; every training day has a carb surge (anchor beforeSession)")
        week_report = {"name": wname, "days": []}
        for day, meals in (("training", training), ("rest", rest)):
            total = {"p": 0, "c": 0, "f": 0}
            rows = []
            meal_count = 0
            forward_seen = False
            for i, meal in enumerate(meals):
                mtag = f"{wtag} ({wname}) {day} meal {i + 1}"
                if not isinstance(meal, dict):
                    errors.append(f"{mtag}: not an object"); continue
                name = meal.get("name") if isinstance(meal.get("name"), str) and meal["name"].strip() else None
                if not name:
                    errors.append(f"{mtag}: name is required"); name = f"meal {i + 1}"
                kind = meal.get("kind", "meal")
                if kind not in ("meal", "fuel"):
                    errors.append(f"{mtag} ({name}): kind must be meal or fuel")
                anchor = meal.get("anchor")
                if anchor not in ANCHORS:
                    errors.append(f"{mtag} ({name}): anchor must be one of {sorted(ANCHORS)}")
                elif day == "rest" and anchor != "forward":
                    errors.append(f"{mtag} ({name}): a rest day has no session, so every rest meal is forward")
                text_problems(meal, f"{mtag} ({name})", errors)
                offset = meal.get("offsetMinutes")
                if not isinstance(offset, int) or isinstance(offset, bool) or offset < 0:
                    errors.append(f"{mtag} ({name}): offsetMinutes must be a whole number of minutes, 0 or more")
                elif anchor == "forward":
                    if not forward_seen and offset != 0:
                        notes.append(f"{mtag} ({name}): the first forward meal usually carries offsetMinutes 0 so it sits on wake time")
                    forward_seen = True
                items = meal.get("items")
                stated = meal.get("stated")
                if kind == "fuel":
                    if items or stated:
                        errors.append(f"{mtag} ({name}): fuel carries no items and no stated macros")
                    rows.append((name, anchor, None))
                    continue
                meal_count += 1
                m = plate(meal, foods, f"{mtag} ({name})", errors, notes)
                if m is None:
                    continue
                total = add(total, m)
                rows.append((name, anchor, m))
            if not meals:
                continue
            target = None
            if day == "training":
                target = targets_override or (targets or {}).get("training")
            else:
                target = rest_override or (targets or {}).get("rest")
            week_report["days"].append({"day": day, "rows": rows, "total": total, "count": meal_count, "target": target})
        report.append(week_report)
    return errors, notes, report


def text_problems(meal, tag, errors):
    """`note` is one line of text and `steps` a list of lines, or the app can't read the file."""
    if not is_text(meal.get("note")):
        errors.append(f"{tag}: note must be text")
    if not is_text_list(meal.get("steps")):
        errors.append(f"{tag}: steps must be a list of text lines")


def plate(meal, foods, tag, errors, notes):
    """The macros of one plate from its items (or stated), or None after an error."""
    items = meal.get("items")
    stated = meal.get("stated")
    m = {"p": 0, "c": 0, "f": 0}
    if items:
        if not isinstance(items, list):
            errors.append(f"{tag}: items must be a list"); return None
        for j, it in enumerate(items):
            itag = f"{tag} item {j + 1}"
            if not isinstance(it, dict):
                errors.append(f"{itag}: not an object"); return None
            fid = it.get("food")
            food = foods.get(fid) if isinstance(fid, str) else None
            if food is None:
                errors.append(f"{itag}: '{fid}' is not a built-in ingredient and is not declared under ingredients (or foods)"); return None
            q = it.get("quantity")
            if not is_number(q) or q <= 0:
                errors.append(f"{itag} ({food['name']}): quantity must be a positive number in {food['unit']}s"); return None
            if q > QUANTITY_MAX[food["unit"]]:
                errors.append(f"{itag}: {q} {food['unit']} of {food['name']} is not a plate (cap {QUANTITY_MAX[food['unit']]}); check the unit")
                return None
            lm = {k: food["per"][k] * q for k in ("p", "c", "f")}
            if kcal(lm) > LINE_KCAL_MAX:
                errors.append(f"{itag}: {q} {food['unit']} of {food['name']} is {round(kcal(lm))} kcal, over the {LINE_KCAL_MAX} line ceiling; check the unit")
            m = add(m, lm)
        if stated is not None:
            notes.append(f"{tag}: has items, so stated is ignored by the app")
    elif stated is not None:
        if not macros_ok(stated):
            errors.append(f"{tag}: stated must be {{p, c, f}} in grams"); return None
        m = {k: float(stated[k]) for k in ("p", "c", "f")}
    else:
        errors.append(f"{tag}: a meal needs items or stated macros (or kind fuel)")
        return None
    if kcal(m) > MEAL_KCAL_MAX:
        errors.append(f"{tag}: {round(kcal(m))} kcal is not one meal (ceiling {MEAL_KCAL_MAX})")
    return m


def gap_text(total, target):
    parts = []
    for k, label in (("p", "protein"), ("c", "carbs"), ("f", "fat")):
        if not target.get(k):
            continue
        diff = total[k] - target[k]
        pct = diff / target[k] * 100
        if abs(pct) > 5:
            parts.append(f"{label} {'+' if diff > 0 else ''}{round(diff)} g ({'+' if pct > 0 else ''}{round(pct)}%)")
    return "on target within 5%" if not parts else "; ".join(parts)


def print_report(report):
    for week in report:
        print(f"\n== {week['name']} ==")
        for d in week["days"]:
            print(f"  {d['count']} meals for the Meals shelf" if d["day"] == "shelf" else f"  {d['day']} day: {d['count']} meals")
            for name, anchor, m in d["rows"]:
                if m is None:
                    print(f"    - {name} (fuel, {anchor})")
                else:
                    print(f"    - {name} ({anchor}): {line(m)}")
            if d["total"] is not None:
                print(f"    total: {line(d['total'])}")
            if d["target"]:
                t = d["target"]
                print(f"    target: {round(t['p'])}P {round(t['c'])}C {round(t['f'])}F: {gap_text(d['total'], t)}")
                if d["count"]:
                    per = d["total"]["p"] / d["count"]
                    if per < PROTEIN_BAND[0]:
                        print(f"    note: about {round(per)} g protein a meal; under {PROTEIN_BAND[0]} spreads the protein thin")
                    elif per > PROTEIN_BAND[1]:
                        print(f"    note: about {round(per)} g protein a meal; over {PROTEIN_BAND[1]} is more than one sitting uses well")


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 2
    path = Path(argv[1])
    targets = rest = None
    if "--targets" in argv:
        targets = parse_targets(argv[argv.index("--targets") + 1])
    if "--rest-targets" in argv:
        rest = parse_targets(argv[argv.index("--rest-targets") + 1])
    try:
        doc = json.loads(path.read_text())
    except Exception as e:  # noqa: BLE001
        print(f"REFUSED: not JSON: {e}")
        return 1
    pantry = load_pantry()
    errors, notes, report = check(doc, pantry, targets, rest)
    print_report(report)
    for n in notes:
        print(f"note: {n}")
    if errors:
        print("\nREFUSED. The app would not import this file:")
        for e in errors:
            print(f"  - {e}")
        return 1
    print("\nOK. The app would import this file whole.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
