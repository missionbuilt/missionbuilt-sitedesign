#!/usr/bin/env python3
"""Check a MealStack plan file the way the app does, and say what it adds up to.

    python3 check_plan.py my-plan.mealstack
    python3 check_plan.py my-plan.mealstack --targets 230,360,63 --recovery-targets 220,272,73

--targets is the training day's; --recovery-targets is the recovery day's.

Format 2 (`"mealstack": 2`) is what the app reads and what to write: each stack's
recovery day is its `recovery` list, and the recovery day's target is `targets.recovery`.
A format 2 file that still says `rest` there is refused, with the rename. Format 1
(`"mealstack": 1`, or no `mealstack` key), which called both of them `rest`, is read the
way the app reads it until 2026-11-30: translated, `rest` to `recovery`, then checked as
format 2, with a note to write format 2. Anything above 2 is a newer format and refused.

Exit 0 when the app would import the file. Exit 1 with one line per problem when it
would refuse it. Either way, prints each stack's training and recovery day: its count
("training day: 5 meals · 3 fuel"), meal and fuel item by item with their macros, the
day's total (fuel included), and the gap against the targets (the file's own, or the
ones passed in).

Fuel is what you take for the session rather than as a meal. It may carry items or
stated macros, which count toward the day's totals, and it is never in the meal
count. Anything anchored atSession is fuel whatever its kind says. No dependencies beyond the standard library. The built-in
ingredients it knows are in references/pantry.json next to this script's folder.

Declared ingredients go under `ingredients`, or under `foods`, the spelling the 0.9
app reads. A file with both is read by `ingredients` and `foods` is ignored, the
same rule as `stacks` and `weeks`.
"""

import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
PANTRY_FILE = HERE.parent / "references" / "pantry.json"

VERSION = 2
# Format 1 called the recovery day `rest`. The app translates it on the way in until the
# sunset, and so does this.
FORMAT_1 = 1
FORMAT_1_SUNSET = "2026-11-30"
UNITS = {"gram", "ounce", "each", "cup", "tbsp", "tsp", "scoop", "packet", "bottle"}
ANCHORS = {"forward", "beforeSession", "atSession", "afterSession"}
# Per unit, above which a declared ingredient is refused as mis-stated (kcal in one unit).
FOOD_KCAL_MAX = {"gram": 9.1, "ounce": 260, "tsp": 50, "tbsp": 140, "cup": 1000, "each": 1000,
                 "scoop": 400, "packet": 400, "bottle": 800}
# Grams of macros one unit can physically hold (a unit weighs at most this much).
FOOD_GRAMS_MAX = {"gram": 1, "ounce": 28.35, "tsp": 7.5, "tbsp": 22, "cup": 340, "scoop": 60, "packet": 60, "bottle": 600}
# The most of one ingredient a plate can hold, in its unit.
QUANTITY_MAX = {"gram": 2000, "ounce": 64, "each": 24, "cup": 8, "tbsp": 16, "tsp": 24,
                "scoop": 6, "packet": 6, "bottle": 6}
LINE_KCAL_MAX = 1500
MEAL_KCAL_MAX = 3000
# The furthest a meal sits from its anchor: one day.
OFFSET_MAX = 1440
# What one file may hold; the app refuses a file past any of these (PlanImporter.Limits).
FILE_BYTES_MAX = 1000000
STACKS_MAX = 52
MEALS_PER_DAY_MAX = 16
SHELF_MEALS_MAX = 200
INGREDIENTS_MAX = 400
ITEMS_PER_MEAL_MAX = 40
STEPS_PER_MEAL_MAX = 40
NAME_MAX = 200
TEXT_MAX = 2000
NOTES_MAX = 4000
TARGET_GRAMS_MAX = 1500
ID_RE = re.compile(r"^[A-Za-z][A-Za-z0-9._-]*$")
TIME_RE = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")
# Protein per meal outside this band earns a note (the app's readout uses the same).
PROTEIN_BAND = (25, 60)


def kcal(m):
    return m["p"] * 4 + m["c"] * 4 + m["f"] * 9


def add(a, b):
    return {"p": a["p"] + b["p"], "c": a["c"] + b["c"], "f": a["f"] + b["f"]}


def is_number(v):
    # JSON true/false are ints to Python and not numbers to the app.
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def is_text(v):
    return v is None or isinstance(v, str)


def is_text_list(v):
    return v is None or (isinstance(v, list) and all(isinstance(x, str) for x in v))


def macros_ok(m):
    return isinstance(m, dict) and all(is_number(m.get(k)) and m[k] >= 0 for k in ("p", "c", "f"))


def line(m):
    return f"{round(m['p'])}P {round(m['c'])}C {round(m['f'])}F, {round(kcal(m))} kcal"


def parse_targets(text):
    if not text:
        return None
    p, c, f = (float(x) for x in text.split(","))
    return {"p": p, "c": c, "f": f}


def load_pantry():
    data = json.loads(PANTRY_FILE.read_text())
    return {f["id"]: f for f in data["foods"]}


def limit_problems(doc):
    """Counts and lengths past what the app reads (PlanImporter.Limits)."""
    out = []
    def long(v, cap):
        return isinstance(v, str) and len(v) > cap
    stacks = doc.get("stacks") if doc.get("stacks") is not None else doc.get("weeks")
    stacks = stacks if isinstance(stacks, list) else []
    shelf = doc.get("meals") if isinstance(doc.get("meals"), list) else []
    declared = doc.get("ingredients") if doc.get("ingredients") is not None else doc.get("foods")
    declared = declared if isinstance(declared, list) else []
    if len(stacks) > STACKS_MAX:
        out.append(f"{len(stacks)} stacks; a file holds at most {STACKS_MAX}")
    if len(shelf) > SHELF_MEALS_MAX:
        out.append(f"{len(shelf)} meals on their own; a file holds at most {SHELF_MEALS_MAX}")
    if len(declared) > INGREDIENTS_MAX:
        out.append(f"{len(declared)} ingredients; a file holds at most {INGREDIENTS_MAX}")
    if long(doc.get("name"), NAME_MAX):
        out.append(f"name is longer than {NAME_MAX} characters")
    if long(doc.get("notes"), NOTES_MAX):
        out.append(f"notes are longer than {NOTES_MAX} characters")
    for f in declared:
        if isinstance(f, dict) and any(long(f.get(k), NAME_MAX) for k in ("id", "name", "qualifier")):
            out.append(f"an ingredient's id, name or qualifier is longer than {NAME_MAX} characters")
    meals = [m for m in shelf if isinstance(m, dict)]
    for w, week in enumerate(stacks):
        if not isinstance(week, dict):
            continue
        if long(week.get("name"), NAME_MAX):
            out.append(f"stack {w + 1}: name is longer than {NAME_MAX} characters")
        if long(week.get("note"), TEXT_MAX):
            out.append(f"stack {w + 1}: note is longer than {TEXT_MAX} characters")
        for day in ("training", "recovery"):
            day_meals = week.get(day) if isinstance(week.get(day), list) else []
            if len(day_meals) > MEALS_PER_DAY_MAX:
                out.append(f"stack {w + 1} {day}: {len(day_meals)} meals; a day holds at most {MEALS_PER_DAY_MAX}")
            meals += [m for m in day_meals if isinstance(m, dict)]
    for m in meals:
        items = m.get("items") if isinstance(m.get("items"), list) else []
        steps = m.get("steps") if isinstance(m.get("steps"), list) else []
        if long(m.get("name"), NAME_MAX):
            out.append(f"a meal's name is longer than {NAME_MAX} characters")
        if len(items) > ITEMS_PER_MEAL_MAX:
            out.append(f"{m.get('name')}: {len(items)} items; a plate holds at most {ITEMS_PER_MEAL_MAX}")
        if any(isinstance(i, dict) and long(i.get("food"), NAME_MAX) for i in items):
            out.append(f"{m.get('name')}: an ingredient id is longer than {NAME_MAX} characters")
        if long(m.get("note"), TEXT_MAX):
            out.append(f"{m.get('name')}: note is longer than {TEXT_MAX} characters")
        if len(steps) > STEPS_PER_MEAL_MAX or any(long(x, TEXT_MAX) for x in steps):
            out.append(f"{m.get('name')}: at most {STEPS_PER_MEAL_MAX} steps of {TEXT_MAX} characters each")
    return out


def renamed(d, old, new):
    """A copy of d with the key old renamed to new, in the same place."""
    return {(new if k == old else k): v for k, v in d.items()}


def from_format_1(doc, errors):
    """A format 1 document as format 2: `rest` becomes `recovery` in every stack (under
    `stacks` or the older `weeks`) and in `targets`. What the app does on the way in."""
    doc = dict(doc)
    doc["mealstack"] = VERSION
    for key in ("stacks", "weeks"):
        if isinstance(doc.get(key), list):
            out = []
            for w, week in enumerate(doc[key]):
                if isinstance(week, dict) and "rest" in week:
                    if "recovery" in week:
                        errors.append(f"stack {w + 1}: has both rest and recovery; a format 1 file says rest, a format 2 file says recovery")
                    week = renamed(week, "rest", "recovery")
                out.append(week)
            doc[key] = out
    targets = doc.get("targets")
    if isinstance(targets, dict) and "rest" in targets:
        if "recovery" in targets:
            errors.append("targets: has both rest and recovery; a format 1 file says rest, a format 2 file says recovery")
        doc["targets"] = renamed(targets, "rest", "recovery")
    return doc


def rename_problem(where):
    """The reason a format 2 file that still says rest is refused. It names the rename."""
    return f"{where}: rest is the format 1 name for the recovery day; a format 2 file writes it as recovery"


def check(doc, pantry, targets_override=None, recovery_override=None):
    errors = []
    notes = []
    if not isinstance(doc, dict):
        return ["the file is not a JSON object"], notes, []
    # The version first, on its own, as the app reads it: a format it does not know is free
    # to have any shape, so nothing else about it is worth reporting.
    version = doc.get("mealstack", FORMAT_1)
    if not is_number(version) or version != int(version) or version < FORMAT_1:
        return [f"mealstack must be {VERSION} (got {version!r})"], notes, []
    if version > VERSION:
        return [f"mealstack {version!r} is a newer format than the app reads; mealstack must be {VERSION}"], notes, []
    if version == FORMAT_1:
        # Read, not refused: translated the way the app translates it, until the sunset.
        doc = from_format_1(doc, errors)
        notes.append(f"format 1: read with rest as recovery, as the app does until {FORMAT_1_SUNSET}. Write format 2: \"mealstack\": {VERSION}, and recovery for each stack's recovery list and the recovery day's target")
    errors += limit_problems(doc)
    if not isinstance(doc.get("name"), str) or not doc["name"].strip():
        errors.append("name is required")
    if not is_text(doc.get("notes")):
        errors.append("notes must be text")
    notes_text = doc.get("notes") if isinstance(doc.get("notes"), str) else ""
    if "not medical advice" not in notes_text.lower():
        notes.append("notes: carry the caveat ('General nutrition information for healthy adults, not medical advice. Written by an AI from your answers; check with a physician or registered dietitian before changing how you eat.') so it shows on the import preview")

    schedule = doc.get("schedule")
    if schedule is not None:
        if not isinstance(schedule, dict):
            errors.append("schedule must be an object")
        else:
            for key in ("wake", "session", "latestMeal"):
                v = schedule.get(key)
                if v is not None and not (isinstance(v, str) and TIME_RE.match(v)):
                    errors.append(f"schedule.{key} must be HH:MM (24-hour), got {v!r}")
            days = schedule.get("trainingWeekdays")
            if days is not None and not (isinstance(days, list) and all(isinstance(d, int) and 1 <= d <= 7 for d in days)):
                errors.append("schedule.trainingWeekdays must be a list of 1 (Sunday) to 7 (Saturday)")

    targets = doc.get("targets")
    if targets is not None:
        if not isinstance(targets, dict):
            errors.append("targets must be an object")
        else:
            if "rest" in targets:
                errors.append(rename_problem("targets"))
            for key in ("training", "recovery"):
                if key in targets and macros_ok(targets[key]) and max(targets[key][k] for k in ("p", "c", "f")) > TARGET_GRAMS_MAX:
                    errors.append(f"targets.{key}: each macro is at most {TARGET_GRAMS_MAX} g")
                if key in targets and not macros_ok(targets[key]):
                    errors.append(f"targets.{key} must be {{p, c, f}} in grams")

    foods = dict(pantry)
    # "ingredients" is the documented key; "foods" is what the 0.9 app reads and still
    # reads. With both, "ingredients" wins and "foods" is ignored, as the app does.
    key = "ingredients" if doc.get("ingredients") is not None else "foods"
    declared = doc.get(key) or []
    if not isinstance(declared, list):
        errors.append(f"{key} must be a list")
        declared = []
    for i, f in enumerate(declared):
        tag = f"{key}[{i}]"
        if not isinstance(f, dict):
            errors.append(f"{tag}: not an object"); continue
        fid = f.get("id")
        if not isinstance(fid, str) or not ID_RE.match(fid):
            errors.append(f"{tag}: id must start with a letter and use only letters, digits, '.', '_' and '-' (got {fid!r})"); continue
        if fid in pantry:
            errors.append(f"{tag}: '{fid}' is already a built-in ingredient; reference it instead of declaring it"); continue
        if not isinstance(f.get("name"), str) or not f["name"].strip():
            errors.append(f"{tag} ({fid}): name is required")
        if not is_text(f.get("qualifier")):
            errors.append(f"{tag} ({fid}): qualifier must be text")
        unit = f.get("unit")
        if unit not in UNITS:
            errors.append(f"{tag} ({fid}): unit must be one of {sorted(UNITS)}"); continue
        per = f.get("per")
        if not macros_ok(per):
            errors.append(f"{tag} ({fid}): per must be {{p, c, f}} grams in one {unit}"); continue
        if kcal(per) > FOOD_KCAL_MAX[unit]:
            errors.append(f"{tag} ({fid}): {round(kcal(per))} kcal in one {unit} is over the {FOOD_KCAL_MAX[unit]} ceiling; the figure is for the wrong unit")
        elif unit in FOOD_GRAMS_MAX and per["p"] + per["c"] + per["f"] > FOOD_GRAMS_MAX[unit]:
            errors.append(f"{tag} ({fid}): {round(per['p'] + per['c'] + per['f'])} g of macros in one {unit}, which weighs at most {FOOD_GRAMS_MAX[unit]} g; the figure is for the wrong unit")
        foods[fid] = {"id": fid, "name": f["name"], "unit": unit, "per": per}

    report = []
    # "stacks" is the key; "weeks" is the older spelling and still reads.
    weeks = doc.get("stacks") if doc.get("stacks") is not None else (doc.get("weeks") or [])
    shelf_meals = doc.get("meals") or []
    if not isinstance(weeks, list):
        errors.append("stacks must be a list"); weeks = []
    if not isinstance(shelf_meals, list):
        errors.append("meals must be a list"); shelf_meals = []
    if not weeks and not shelf_meals and not declared:
        errors.append("the file has no stacks, no meals and no ingredients: nothing to import")
        return errors, notes, report

    # Meals on their own: the same plate, no time.
    if shelf_meals:
        rows = []
        for i, meal in enumerate(shelf_meals):
            mtag = f"meal {i + 1}"
            if not isinstance(meal, dict):
                errors.append(f"{mtag}: not an object"); continue
            name = meal.get("name") if isinstance(meal.get("name"), str) and meal["name"].strip() else None
            if not name:
                errors.append(f"{mtag}: name is required"); name = mtag
            for key in ("anchor", "offsetMinutes", "kind"):
                if key in meal:
                    errors.append(f"{mtag} ({name}): a meal on its own has no {key}; that belongs to a meal inside a stack")
            text_problems(meal, f"{mtag} ({name})", errors)
            m = plate(meal, foods, f"{mtag} ({name})", errors, notes)
            if m is None:
                continue
            rows.append((name, "shelf", m, "meal"))
        if rows:
            report.append({"name": "Meals for the shelf", "days": [{"day": "shelf", "rows": rows, "total": None, "count": len(rows),
                                                                    "fuel": 0, "meal_protein": None, "target": None}]})

    for w, week in enumerate(weeks):
        wtag = f"stack {w + 1}"
        if not isinstance(week, dict):
            errors.append(f"{wtag}: not an object"); continue
        wname = week.get("name") if isinstance(week.get("name"), str) else f"Stack {w + 1}"
        # The app reads a stack only whole: a name, a training list and a recovery list,
        # each present even when empty.
        if not isinstance(week.get("name"), str):
            errors.append(f"{wtag}: name is required (text; it may be empty)")
        if not is_text(week.get("note")):
            errors.append(f"{wtag} ({wname}): note must be text")
        if "rest" in week:
            errors.append(rename_problem(f"{wtag} ({wname})")); continue
        missing = [k for k in ("training", "recovery") if k not in week or week[k] is None]
        if missing:
            errors.append(f"{wtag} ({wname}): {' and '.join(missing)} {'is' if len(missing) == 1 else 'are'} required; write [] for a day with no meals"); continue
        training = week["training"]
        recovery = week["recovery"]
        if not isinstance(training, list) or not isinstance(recovery, list):
            errors.append(f"{wtag} ({wname}): training and recovery must be lists"); continue
        if not training and not recovery:
            errors.append(f"{wtag} ({wname}): a stack needs at least one meal"); continue
        if training and not any(isinstance(m, dict) and m.get("anchor") == "beforeSession" and not is_fuel(m) for m in training):
            errors.append(f"{wtag} ({wname}): the training day has no meal pinned before the session; every training day has a carb surge (anchor beforeSession)")
        week_report = {"name": wname, "days": []}
        for day, meals in (("training", training), ("recovery", recovery)):
            total = {"p": 0, "c": 0, "f": 0}
            rows = []
            meal_count = 0
            fuel_count = 0
            meal_protein = 0
            forward_seen = False
            for i, meal in enumerate(meals):
                mtag = f"{wtag} ({wname}) {day} meal {i + 1}"
                if not isinstance(meal, dict):
                    errors.append(f"{mtag}: not an object"); continue
                name = meal.get("name") if isinstance(meal.get("name"), str) and meal["name"].strip() else None
                if not name:
                    errors.append(f"{mtag}: name is required"); name = f"meal {i + 1}"
                kind = meal.get("kind", "meal")
                if kind not in ("meal", "fuel"):
                    errors.append(f"{mtag} ({name}): kind must be meal or fuel")
                anchor = meal.get("anchor")
                if anchor == "atSession" and kind != "fuel":
                    if "kind" in meal:
                        notes.append(f"{mtag} ({name}): anchored atSession, so it is fuel, not a meal; the app reads it as fuel. Write \"kind\": \"fuel\"")
                    else:
                        notes.append(f"{mtag} ({name}): anchored atSession, so it is fuel; write \"kind\": \"fuel\" so every reader sees it")
                if anchor not in ANCHORS:
                    errors.append(f"{mtag} ({name}): anchor must be one of {sorted(ANCHORS)}")
                elif day == "recovery" and anchor != "forward":
                    errors.append(f"{mtag} ({name}): a recovery day has no session, so every meal in the recovery list is forward")
                text_problems(meal, f"{mtag} ({name})", errors)
                offset = meal.get("offsetMinutes")
                if not isinstance(offset, int) or isinstance(offset, bool) or offset < 0 or offset > OFFSET_MAX:
                    errors.append(f"{mtag} ({name}): offsetMinutes must be a whole number of minutes, 0 to {OFFSET_MAX}")
                elif anchor == "forward":
                    if not forward_seen and offset != 0:
                        notes.append(f"{mtag} ({name}): the first forward meal usually carries offsetMinutes 0 so it sits on wake time")
                    forward_seen = True
                fuel = is_fuel(meal)
                if fuel:
                    fuel_count += 1
                    # Fuel may carry a plate (the shake after the session, the jug) or
                    # nothing at all (water, creatine). What it carries counts.
                    empty = not meal.get("items") and meal.get("stated") is None
                    m = None if empty else plate(meal, foods, f"{mtag} ({name})", errors, notes)
                    if m is not None:
                        total = add(total, m)
                    rows.append((name, anchor, m, "fuel"))
                    continue
                meal_count += 1
                m = plate(meal, foods, f"{mtag} ({name})", errors, notes)
                if m is None:
                    continue
                total = add(total, m)
                meal_protein += m["p"]
                rows.append((name, anchor, m, "meal"))
            if not meals:
                continue
            target = None
            if day == "training":
                target = targets_override or (targets or {}).get("training")
            else:
                target = recovery_override or (targets or {}).get("recovery")
            week_report["days"].append({"day": day, "rows": rows, "total": total, "count": meal_count,
                                        "fuel": fuel_count, "meal_protein": meal_protein, "target": target})
        report.append(week_report)
    return errors, notes, report


def is_fuel(meal):
    """Fuel by its kind, or by its anchor: anything pinned to the session start is fuel."""
    return meal.get("kind") == "fuel" or meal.get("anchor") == "atSession"


def text_problems(meal, tag, errors):
    """`note` is one line of text and `steps` a list of lines, or the app can't read the file."""
    if not is_text(meal.get("note")):
        errors.append(f"{tag}: note must be text")
    if not is_text_list(meal.get("steps")):
        errors.append(f"{tag}: steps must be a list of text lines")


def plate(meal, foods, tag, errors, notes):
    """The macros of one plate from its items (or stated), or None after an error."""
    items = meal.get("items")
    stated = meal.get("stated")
    m = {"p": 0, "c": 0, "f": 0}
    if items:
        if not isinstance(items, list):
            errors.append(f"{tag}: items must be a list"); return None
        for j, it in enumerate(items):
            itag = f"{tag} item {j + 1}"
            if not isinstance(it, dict):
                errors.append(f"{itag}: not an object"); return None
            fid = it.get("food")
            food = foods.get(fid) if isinstance(fid, str) else None
            if food is None:
                errors.append(f"{itag}: '{fid}' is not a built-in ingredient and is not declared under ingredients (or foods)"); return None
            q = it.get("quantity")
            if not is_number(q) or q <= 0:
                errors.append(f"{itag} ({food['name']}): quantity must be a positive number in {food['unit']}s"); return None
            if q > QUANTITY_MAX[food["unit"]]:
                errors.append(f"{itag}: {q} {food['unit']} of {food['name']} is not a plate (cap {QUANTITY_MAX[food['unit']]}); check the unit")
                return None
            lm = {k: food["per"][k] * q for k in ("p", "c", "f")}
            if kcal(lm) > LINE_KCAL_MAX:
                errors.append(f"{itag}: {q} {food['unit']} of {food['name']} is {round(kcal(lm))} kcal, over the {LINE_KCAL_MAX} line ceiling; check the unit")
            m = add(m, lm)
        if stated is not None:
            notes.append(f"{tag}: has items, so stated is ignored by the app")
    elif stated is not None:
        if not macros_ok(stated):
            errors.append(f"{tag}: stated must be {{p, c, f}} in grams"); return None
        m = {k: float(stated[k]) for k in ("p", "c", "f")}
    else:
        errors.append(f"{tag}: a meal needs items or stated macros (fuel may have neither)")
        return None
    if kcal(m) > MEAL_KCAL_MAX:
        errors.append(f"{tag}: {round(kcal(m))} kcal is not one meal (ceiling {MEAL_KCAL_MAX})")
    return m


def gap_text(total, target):
    parts = []
    for k, label in (("p", "protein"), ("c", "carbs"), ("f", "fat")):
        if not target.get(k):
            continue
        diff = total[k] - target[k]
        pct = diff / target[k] * 100
        if abs(pct) > 5:
            parts.append(f"{label} {'+' if diff > 0 else ''}{round(diff)} g ({'+' if pct > 0 else ''}{round(pct)}%)")
    return "on target within 5%" if not parts else "; ".join(parts)


def count_text(d):
    """'5 meals · 3 fuel': meals only in the count, fuel beside it."""
    meals = f"{d['count']} meal{'' if d['count'] == 1 else 's'}"
    return f"{meals} · {d['fuel']} fuel" if d["fuel"] else meals


def print_report(report):
    for week in report:
        print(f"\n== {week['name']} ==")
        for d in week["days"]:
            if d["day"] == "shelf":
                print(f"  {d['count']} meals for the Meals shelf")
            else:
                print(f"  {d['day']} day: {count_text(d)}")
            for name, anchor, m, kind in d["rows"]:
                tag = f"fuel, {anchor}" if kind == "fuel" else anchor
                print(f"    - {name} ({tag})" if m is None else f"    - {name} ({tag}): {line(m)}")
            if d["total"] is not None:
                print(f"    total: {line(d['total'])}")
            if d["target"]:
                t = d["target"]
                print(f"    target: {round(t['p'])}P {round(t['c'])}C {round(t['f'])}F: {gap_text(d['total'], t)}")
                if d["count"]:
                    # Per meal means per meal: fuel's protein counts toward the day, not toward a sitting.
                    per = d["meal_protein"] / d["count"]
                    if per < PROTEIN_BAND[0]:
                        print(f"    note: about {round(per)} g protein a meal; under {PROTEIN_BAND[0]} spreads the protein thin")
                    elif per > PROTEIN_BAND[1]:
                        print(f"    note: about {round(per)} g protein a meal; over {PROTEIN_BAND[1]} is more than one sitting uses well")


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 2
    path = Path(argv[1])
    targets = recovery = None
    if "--targets" in argv:
        targets = parse_targets(argv[argv.index("--targets") + 1])
    if "--recovery-targets" in argv:
        recovery = parse_targets(argv[argv.index("--recovery-targets") + 1])
    if path.stat().st_size > FILE_BYTES_MAX:
        print(f"REFUSED: the file is larger than a plan file can be ({FILE_BYTES_MAX // 1000000} MB)")
        return 1
    try:
        doc = json.loads(path.read_text())
    except Exception as e:  # noqa: BLE001
        print(f"REFUSED: not JSON: {e}")
        return 1
    pantry = load_pantry()
    errors, notes, report = check(doc, pantry, targets, recovery)
    print_report(report)
    for n in notes:
        print(f"note: {n}")
    if errors:
        print("\nREFUSED. The app would not import this file:")
        for e in errors:
            print(f"  - {e}")
        return 1
    print("\nOK. The app would import this file whole.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
