# The MealStack plan format

A `.mealstack` file: one JSON document that carries any of the three things the app
keeps: ingredients (what one unit of each is worth), meals (ingredients with
amounts), and stacks (a training day and a recovery day of meals, under a name; a stack is what the
rotation runs, one per calendar week). Plus, optionally, the schedule and the daily
targets. A file can be a whole rotation of stacks, one stack, a few meals for the
Meals shelf, or a single ingredient; it lands on the matching shelves whole, and the person
chooses whether a file with stacks also becomes their plan. The app exports any kept
stack or the whole rotation in the same shape. It is the contract a model follows
when writing for MealStack outside the app: the MealStack skill, a coach's
spreadsheet, a friend's plan.

The rule that shapes everything else: the app computes every number itself. A meal
is items and quantities; the app multiplies by what one unit of each ingredient is worth.
A document never states a meal's macros except through `stated`, for a plate that
was never weighed, and never states a day's totals at all.

## Top level

```json
{
  "mealstack": 2,
  "name": "The Rotation",
  "notes": "Four weeks that loop. Week 4 ends, Week 1 starts.",
  "schedule": { "wake": "07:00", "session": "18:00", "latestMeal": "21:30", "trainingWeekdays": [2, 3, 5, 6] },
  "targets": { "training": { "p": 230, "c": 360, "f": 63 }, "recovery": { "p": 220, "c": 272, "f": 73 } },
  "foods": [ ... ],
  "meals": [ ... ],
  "stacks": [ ... ]
}
```

| Key | Required | Meaning |
|---|---|---|
| `mealstack` | yes | Format version. This document describes version `2`. A reader refuses a version it does not know. Format 1, and a file with no `mealstack` key, is still read until 2026-11-30; see [Format 1](#format-1) below. |
| `name` | yes | What the plan is called. Shown on the preview; a single stack imports under its own name. |
| `notes` | no | A sentence or two about the plan. |
| `schedule` | no | Times as `"HH:MM"` (24-hour) and `trainingWeekdays` as 1 = Sunday … 7 = Saturday. The app shows these on the preview and offers to apply them; it never applies them silently. |
| `targets` | no | Grams of protein, carbs and fat for a training day (`training`) and a recovery day (`recovery`). Offered, not applied silently. |
| `foods` | no | Ingredients the app does not have built in. Declared once, referenced by `id` in items. Each lands on the Ingredients shelf. The documented name of this key is `ingredients`; see the note below. |
| `ingredients` | no | The same list under its documented name. Read by the app from 0.9.1. |
| `meals` | no | Meals on their own, for the Meals shelf: a plate with no time. |
| `stacks` | no | Stacks for the Stacks shelf, or the plan. `weeks` is the older spelling of this key and still reads; new files write `stacks`. |

At least one of `foods` (or `ingredients`), `meals` and `stacks` (or `weeks`) must be present and non-empty; a file with none is refused.

> **Note: `ingredients` and `foods`.** `ingredients` is the documented name for the list of declared ingredients, and the app reads it from 0.9.1. The 0.9 app reads only `foods`, so for now every writer (the app's export, the MealStack skill) keeps writing `foods`. `ingredients` becomes the written key once 0.9.1 is the oldest build in use. A reader takes either key. A file with both is read by `ingredients`, and its `foods` is ignored; the same rule holds for `stacks` and its older spelling `weeks`.

## Ingredients

Only what the app does not have built in. The app ships with about 200 built-in ingredients (chicken breast, jasmine rice, 0% Greek yogurt, oat milk, vegan protein powder, and so on; the MealStack skill lists them in its built-in ingredients reference, `references/pantry.md`) and items reference those by their id. When a document needs an ingredient the app does not have, it declares it here (under `foods`, for now) and the app adds it to the person's Ingredients shelf on import.

```json
{ "id": "my.ghost_chocolate", "name": "Ghost vegan protein, chocolate", "unit": "scoop",
  "per": { "p": 21, "c": 4, "f": 2 }, "qualifier": "33 g scoop, from the label" }
```

| Key | Required | Meaning |
|---|---|---|
| `id` | yes | Any string that starts with a letter and contains only letters, digits, `.`, `_` and `-`. Must not be a built-in id (a file that declares one is refused). The app prefixes it on import (`import.<id>`); an id already on the person's shelf with other figures gets a number of its own (`import.<id>-2`). |
| `name` | yes | As it appears on a plate. |
| `unit` | yes | One of `gram`, `ounce`, `each`, `cup`, `tbsp`, `tsp`, `scoop`, `packet`, `bottle`. |
| `per` | yes | Grams of protein, carbs and fat in exactly one unit. Per gram for `gram`; per ounce for `ounce`; per piece, cup, spoon, scoop, packet or bottle otherwise. A cup is 240 ml. |
| `qualifier` | no | What the figure is for: "raw weight", "cooked weight", "1 cup = 240 ml", "from the label". |

Ceilings, per unit, above which an ingredient is refused as mis-stated: 9.1 kcal per gram, 260 per ounce, 50 per tsp, 140 per tbsp, 1,000 per cup or per each, 400 per scoop or packet, 800 per bottle.

## Meals on their own

```json
{ "name": "Tuna rice bowl",
  "items": [ { "food": "tuna_can", "quantity": 2 }, { "food": "rice_cooked", "quantity": 175 },
             { "food": "avocado", "quantity": 0.5 } ],
  "note": "Three minutes, no prep.", "steps": [ "Drain the tuna over the sink; fork it over the rice." ] }
```

A meal for the Meals shelf has a `name`, `items` or `stated`, and optionally `note` and `steps`: the same plate as a meal inside a stack, without `anchor`, `offsetMinutes` or `kind`, because a shelf meal has no time and fuel is never a meal (fuel lives only inside a stack's day). The same ceilings apply. From the shelf the person puts it on a slot for today, for one stack, or for every stack.

## Stacks

```json
{ "name": "Rice Bowls", "note": "Teriyaki chicken at lunch, crispy tofu after training.",
  "training": [ ...meals... ], "recovery": [ ...meals... ] }
```

A stack is one training day and one recovery day of meals and fuel, in the order they are taken, under a name. The recovery day is a day without a session (you can still move and do light work on one). `name`, `training` and `recovery` are all required; `training` and `recovery` may each be an empty list (`[]`) only if the other is not. The rotation is stacks in order, one per calendar week, repeating; every stack in a rotation has the same slots in the same order, and only the plates change.

## Meals and fuel

```json
{ "name": "Paprika chicken box", "anchor": "forward", "offsetMinutes": 180,
  "items": [ { "food": "chicken_raw", "quantity": 7.05 }, { "food": "rice_cooked", "quantity": 225 },
             { "food": "broccoli", "quantity": 150 }, { "food": "olive_oil", "quantity": 0.5 } ],
  "note": "Blue box. Microwave 2½ min, stir, 1½ min.",
  "steps": [ "Reheat lid off.", "Sesame oil after." ] }
```

```json
{ "name": "After-session shake", "kind": "fuel", "anchor": "afterSession", "offsetMinutes": 30,
  "items": [ { "food": "whey", "quantity": 1 }, { "food": "oat_milk", "quantity": 1 } ] }
```

| Key | Required | Meaning |
|---|---|---|
| `name` | yes | |
| `kind` | no | `meal` (default) or `fuel`. Fuel is what you take for the session rather than as a meal: pre-workout, the jug you sip through the session, the shake after it, electrolytes, creatine, water. It can carry protein, carbs and fat, and those count toward the day's totals. Fuel is never a meal: it isn't in the meal count, doesn't move the meals around it, and isn't scored for timing. Anything pinned to the session start is fuel. Fuel keeps its time and its alert and may carry `items` or `stated` like a plate (the shake after the session, the jug with a sports drink in it), or neither (water, creatine on its own). An item anchored `atSession` is fuel whatever `kind` says: a reader treats it as fuel, and the checker notes a `kind` of `meal` there as a mistake to fix. |
| `anchor` | yes | `forward`, `beforeSession`, `atSession` or `afterSession`. Forward meals chain off the meal before them (the first forward meal of the day sits on wake time). The others are pinned to the session and do not move when the morning runs late; `atSession` makes the item fuel. Recovery days have no session, so every meal and fuel item in a `recovery` list is `forward`. Every training day has a carb surge: one meal (not fuel) anchored `beforeSession`, usually 60 to 90 minutes before, carbs stacked, fat light. A training day without one is refused. |
| `offsetMinutes` | yes | For `forward`: minutes after the previous forward meal (0 for the first). For `beforeSession` / `afterSession`: minutes before or after the session. For `atSession`: 0. A whole number from 0 to 1,440 (one day). |
| `items` | one of items / stated for a meal; optional for fuel | Each item is `{ "food": "<ingredient id>", "quantity": <number> }` (the item key is `food`). The quantity is in the ingredient's own unit: grams for a gram ingredient, cups for a cup ingredient (half a cup is 0.5), scoops for a scoop ingredient. Never millilitres or grams against a cup, spoon or scoop ingredient. |
| `stated` | one of items / stated for a meal; optional for fuel | `{ "p", "c", "f" }` in grams, for a plate you know the numbers of but do not weigh. |
| `note` | no | One line under the name. |
| `steps` | no | How it is made: a list of lines, never a single string. |

Ceilings, same as Coach's: a line over 1,500 kcal, a meal over 3,000 kcal, or a quantity over the cap for its unit (2,000 g, 64 oz, 24 each, 8 cups, 16 tbsp, 24 tsp, 6 scoops, 6 packets, 6 bottles) refuses the meal. Fuel with items or stated macros is held to the same ceilings.

A day's totals are every meal and every fuel item on it: the shake after the session and the jug count toward the day's protein, carbs and fat like any plate. The day's meal count is its meals only; fuel is on top of it ("5 meals · 3 fuel"). Five meals a day is the default, and that is five meals, with the fuel beside them.

> **Note: fuel with items.** The app reads `items` and `stated` on fuel, and an `atSession` item as fuel, from 0.9.1. The 0.9 app refuses a fuel item that carries either, and reads an `atSession` item with no `kind` as a meal.

## What the reader does

1. Refuses the document outright, saying why, when: the version is unknown (above 2); a format 2 document still uses a format 1 name, a `rest` list in a stack or a `rest` target (the reason names the rename to `recovery`); a key is missing or holds the wrong kind of value (a stack without `name`, `training` or `recovery`; `steps` that is not a list); it has no ingredients, no meals and no stacks; a stack has no meals; a declared ingredient uses a built-in id; an item names an ingredient that is neither built in nor declared under `foods` (or `ingredients`); an ingredient, a meal or a fuel item is over a ceiling; an anchor is not one of the four; an offset is outside 0 to 1,440; stated macros or a target are negative, or a target is over 1,500 g of any macro; a schedule time is not a 24-hour `HH:MM` or a training day is outside 1 to 7; the file is past a limit below; a meal or fuel item in a `recovery` list is pinned to a session; a training day has no meal pinned before the session (the carb surge; fuel pinned there does not count).
2. Otherwise imports everything, onto all three shelves: declared ingredients onto the Ingredients shelf (ids prefixed `import.`), every meal (the ones under `meals` and the ones inside stacks) onto the Meals shelf marked "imported", and the stacks onto the Stacks shelf, or, if the person chooses "Make it my plan" rather than "Shelves only", as the plan itself with the first stack running this week and the others the rotation. The plan's name and notes go onto each stack's note. Nothing partial: a document lands whole or not at all.
3. Offers the schedule and the targets on the preview as two switches, off by default ("Make it my plan" turns them on).

Using an imported stack is the same as using any stack on the Stacks shelf: open it and run it this week, or add it to the rotation.

Limits, so a file can't stall the phone reading it: at most 1 MB; 52 stacks; 16 meals and fuel on one day; 200 meals under `meals`; 400 declared ingredients; 40 items and 40 steps on one plate; 200 characters in a name, an id or a qualifier; 2,000 in a note or a step; 4,000 in the plan's `notes`.

## Format 1

Files written before MealStack 0.13 (the app's export, the MealStack skill, Coach) are format 1: `"mealstack": 1`, or no `mealstack` key at all. Format 1 is format 2 with the older name for the recovery day: a stack's recovery list is `rest` (under `stacks` or the older spelling `weeks`), and so is the recovery day's target (`targets.rest`). Everything else is the same.

A reader takes a format 1 file by translating it on the way in, `rest` to `recovery` in each stack and in `targets`, and then reads it as format 2 with every rule above. A format 2 file that still says `rest` is refused, not translated: a file that declares format 2 means it. The translation is read-only and temporary: nothing writes format 1 any more, and the app stops reading it after 2026-11-30, the same day Coach stops answering builds from before 0.13 in the older words. To keep a format 1 file past that date, bring it in before then and export it again from the Stacks shelf, or rename `rest` to `recovery` and set `"mealstack": 2` by hand.

## The file

The file is JSON with the extension `.mealstack` (type `io.missionbuilt.mealstack.plan`, which conforms to `public.json`). The app is registered for it, so a `.mealstack` file opened from Mail, Messages, AirDrop or Files goes straight into the import sheet with its preview up; a plain `.json` file finds the app in the share sheet as an alternate, or can be chosen from the sheet's file picker or pasted.

## Export

Any kept stack, or the whole rotation, exports in this shape (format 2) from the Stacks shelf as `<name>.mealstack`. Ingredients that are not built in (the person's own) are written under `foods` so the document stands on its own; see the note on `ingredients` above.
