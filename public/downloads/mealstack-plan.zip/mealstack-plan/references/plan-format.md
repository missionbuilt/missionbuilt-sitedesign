# The MealStack plan format

A `.mealstack` file: one JSON document that carries any of the three things the app
keeps: ingredients (what one unit of each is worth), meals (ingredients with
amounts), and stacks (a training day and a rest day of meals, under a name; a stack is what the
rotation runs, one per calendar week). Plus, optionally, the schedule and the daily
targets. A file can be a whole rotation of stacks, one stack, a few meals for the
Meals shelf, or a single ingredient; it lands on the matching shelves whole, and the person
chooses whether a file with stacks also becomes their plan. The app exports any kept
stack or the whole rotation in the same shape. It is the contract a model follows
when writing for MealStack outside the app: the MealStack skill, a coach's
spreadsheet, a friend's plan.

The rule that shapes everything else: the app computes every number itself. A meal
is items and quantities; the app multiplies by what one unit of each ingredient is worth.
A document never states a meal's macros except through `stated`, for a plate that
was never weighed, and never states a day's totals at all.

## Top level

```json
{
  "mealstack": 1,
  "name": "The Rotation",
  "notes": "Four weeks that loop. Week 4 ends, Week 1 starts.",
  "schedule": { "wake": "07:00", "session": "18:00", "latestMeal": "21:30", "trainingWeekdays": [2, 3, 5, 6] },
  "targets": { "training": { "p": 230, "c": 360, "f": 63 }, "rest": { "p": 220, "c": 272, "f": 73 } },
  "foods": [ ... ],
  "meals": [ ... ],
  "stacks": [ ... ]
}
```

| Key | Required | Meaning |
|---|---|---|
| `mealstack` | yes | Format version. This document describes version `1`. A reader refuses a version it does not know. |
| `name` | yes | What the plan is called. Shown on the preview; a single stack imports under its own name. |
| `notes` | no | A sentence or two about the plan. |
| `schedule` | no | Times as `"HH:MM"` (24-hour) and `trainingWeekdays` as 1 = Sunday … 7 = Saturday. The app shows these on the preview and offers to apply them; it never applies them silently. |
| `targets` | no | Grams of protein, carbs and fat for a training day and a rest day. Offered, not applied silently. |
| `foods` | no | Ingredients the app does not have built in. Declared once, referenced by `id` in items. Each lands on the Ingredients shelf. The documented name of this key is `ingredients`; see the note below. |
| `ingredients` | no | The same list under its documented name. Read by the app from 0.9.1. |
| `meals` | no | Meals on their own, for the Meals shelf: a plate with no time. |
| `stacks` | no | Stacks for the Stacks shelf, or the plan. `weeks` is the older spelling of this key and still reads; new files write `stacks`. |

At least one of `foods` (or `ingredients`), `meals` and `stacks` (or `weeks`) must be present and non-empty; a file with none is refused.

> **Note: `ingredients` and `foods`.** `ingredients` is the documented name for the list of declared ingredients, and the app reads it from 0.9.1. The 0.9 app reads only `foods`, so for now every writer (the app's export, the MealStack skill) keeps writing `foods`. `ingredients` becomes the written key once 0.9.1 is the oldest build in use. A reader takes either key. A file with both is read by `ingredients`, and its `foods` is ignored; the same rule holds for `stacks` and its older spelling `weeks`.

## Ingredients

Only what the app does not have built in. The app ships with about 200 built-in ingredients (chicken breast, jasmine rice, Fage 0%, oat milk, Ghost vegan protein, and so on; the MealStack skill lists them in its built-in ingredients reference, `references/pantry.md`) and items reference those by their id. When a document needs an ingredient the app does not have, it declares it here (under `foods`, for now) and the app adds it to the person's Ingredients shelf on import.

```json
{ "id": "my.ghost_chocolate", "name": "Ghost vegan protein, chocolate", "unit": "scoop",
  "per": { "p": 21, "c": 4, "f": 2 }, "qualifier": "33 g scoop, from the label" }
```

| Key | Required | Meaning |
|---|---|---|
| `id` | yes | Any string that starts with a letter and contains only letters, digits, `.`, `_` and `-`. Must not collide with a built-in id; the app prefixes it on import so it never can. |
| `name` | yes | As it appears on a plate. |
| `unit` | yes | One of `gram`, `ounce`, `each`, `cup`, `tbsp`, `tsp`, `scoop`, `packet`, `bottle`. |
| `per` | yes | Grams of protein, carbs and fat in exactly one unit. Per gram for `gram`; per ounce for `ounce`; per piece, cup, spoon, scoop, packet or bottle otherwise. A cup is 240 ml. |
| `qualifier` | no | What the figure is for: "raw weight", "cooked weight", "1 cup = 240 ml", "from the label". |

Ceilings, per unit, above which an ingredient is refused as mis-stated: 9.1 kcal per gram, 260 per ounce, 50 per tsp, 140 per tbsp, 1,000 per cup or per each, 400 per scoop or packet, 800 per bottle.

## Meals on their own

```json
{ "name": "Tuna rice bowl",
  "items": [ { "food": "tuna_can", "quantity": 2 }, { "food": "rice_cooked", "quantity": 175 },
             { "food": "avocado", "quantity": 0.5 } ],
  "note": "Three minutes, no prep.", "steps": [ "Drain the tuna over the sink; fork it over the rice." ] }
```

A meal for the Meals shelf has a `name`, `items` or `stated`, and optionally `note` and `steps`: the same plate as a meal inside a stack, without `anchor`, `offsetMinutes` or `kind`, because a shelf meal has no time and fuel is not a meal. The same ceilings apply. From the shelf the person puts it on a slot for today, for one stack, or for every stack.

## Stacks

```json
{ "name": "Rice Bowls", "note": "Teriyaki chicken at lunch, crispy tofu after training.",
  "training": [ ...meals... ], "rest": [ ...meals... ] }
```

A stack is one training day and one rest day of meals, in the order they are eaten, under a name. `training` and `rest` may each be empty only if the other is not. The rotation is stacks in order, one per calendar week, repeating; every stack in a rotation has the same slots in the same order, and only the plates change.

## Meals

```json
{ "name": "Paprika chicken box", "anchor": "forward", "offsetMinutes": 180,
  "items": [ { "food": "chicken_raw", "quantity": 7.05 }, { "food": "rice_cooked", "quantity": 225 },
             { "food": "broccoli", "quantity": 150 }, { "food": "olive_oil", "quantity": 0.5 } ],
  "note": "Blue box. Microwave 2½ min, stir, 1½ min.",
  "steps": [ "Reheat lid off.", "Sesame oil after." ] }
```

| Key | Required | Meaning |
|---|---|---|
| `name` | yes | |
| `kind` | no | `meal` (default) or `fuel`. Fuel is what you take for training that is not protein, carbs or fat: water, electrolytes, pre-workout, creatine, a supplement. Fuel has no items and no stated macros, keeps its time and its alert, and never counts as a meal. |
| `anchor` | yes | `forward`, `beforeSession`, `atSession` or `afterSession`. Forward meals chain off the meal before them (the first forward meal of the day sits on wake time). The others are pinned to the session and do not move when the morning runs late. Rest days have no session, so rest meals are all `forward`. Every training day has a carb surge: one meal (not fuel) anchored `beforeSession`, usually 60 to 90 minutes before, carbs stacked, fat light. A training day without one is refused. |
| `offsetMinutes` | yes | For `forward`: minutes after the previous forward meal (0 for the first). For `beforeSession` / `afterSession`: minutes before or after the session. For `atSession`: 0. |
| `items` | one of items / stated, unless fuel | Each item is `{ "food": "<ingredient id>", "quantity": <number> }` (the item key stays `food` in format 1). The quantity is in the ingredient's own unit: grams for a gram ingredient, cups for a cup ingredient (half a cup is 0.5), scoops for a scoop ingredient. Never millilitres or grams against a cup, spoon or scoop ingredient. |
| `stated` | one of items / stated, unless fuel | `{ "p", "c", "f" }` in grams, for a plate you know the numbers of but do not weigh. |
| `note` | no | One line under the name. |
| `steps` | no | How it is made. |

Ceilings, same as Coach's: a line over 1,500 kcal, a meal over 3,000 kcal, or a quantity over the cap for its unit (2,000 g, 64 oz, 24 each, 8 cups, 16 tbsp, 24 tsp, 6 scoops, 6 packets, 6 bottles) refuses the meal.

## What the reader does

1. Refuses the document outright, saying why, when: the version is unknown; it has no ingredients, no meals and no stacks; a stack has no meals; an item names an ingredient that is neither built in nor declared under `foods` (or `ingredients`); an ingredient or a meal is over a ceiling; an anchor is not one of the four; a rest meal is pinned to a session; a training day has no meal pinned before the session (the carb surge); a fuel item carries items or stated macros.
2. Otherwise imports everything, onto all three shelves: declared ingredients onto the Ingredients shelf (ids prefixed `import.`), every meal (the ones under `meals` and the ones inside stacks) onto the Meals shelf marked "imported", and the stacks onto the Stacks shelf, or, if the person chooses "Make it my plan" rather than "Shelves only", as the plan itself with the first stack running this week and the rest the rotation. The plan's name and notes go onto each stack's note. Nothing partial: a document lands whole or not at all.
3. Offers the schedule and the targets on the preview as two switches, off by default ("Make it my plan" turns them on).

Using an imported stack is the same as using any stack on the Stacks shelf: open it and run it this week, or add it to the rotation.

## The file

The file is JSON with the extension `.mealstack` (type `io.missionbuilt.mealstack.plan`, which conforms to `public.json`). The app is registered for it, so a `.mealstack` file opened from Mail, Messages, AirDrop or Files goes straight into the import sheet with its preview up; a plain `.json` file finds the app in the share sheet as an alternate, or can be chosen from the sheet's file picker or pasted.

## Export

Any kept stack, or the whole rotation, exports in this shape from the Stacks shelf as `<name>.mealstack`. Ingredients that are not built in (the person's own) are written under `foods` so the document stands on its own; see the note on `ingredients` above.
