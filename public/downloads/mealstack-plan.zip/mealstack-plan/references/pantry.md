# The built-in ingredients

Every ingredient the app ships with (built-in ingredients version 4), what one unit is worth in grams of protein, carbs and fat, and the kcal that makes. Reference these by `id` in a plan's items; declare anything else under `foods` (the key app builds in use today read; plan-format.md says when `ingredients` takes over).

Quantities are in the ingredient's unit: grams for a gram ingredient, ounces for an ounce ingredient, pieces for each, cups for a cup ingredient (1 cup = 240 ml, so half a cup is 0.5), spoons, scoops, packets, bottles. Never millilitres or grams against a cup, spoon or scoop ingredient.

## Eggs and dairy

| id | name | unit | P | C | F | kcal | note |
|---|---|---|---|---|---|---|---|
| `egg_whole` | whole egg | each | 6.3 | 0.4 | 4.8 | 70 | large |
| `egg_white` | egg white | each | 3.6 | 0.2 | 0.1 | 16 | ≈30 g from the carton |
| `egg_whites_liquid` | liquid egg whites | 100 g | 10.9 | 0.7 | 0.0 | 46 | from the carton, ½ cup ≈ 130 g |
| `greek_yogurt_0` | 0% Greek yogurt | 100 g | 10.3 | 3.6 | 0.0 | 56 | Fage-style |
| `oat_milk` | oat milk | cup | 1.0 | 7.0 | 1.5 | 46 | unsweetened, 45 kcal a cup, 1 cup = 240 ml, check the label (original runs 120) |

## Grains and starch

| id | name | unit | P | C | F | kcal | note |
|---|---|---|---|---|---|---|---|
| `oats_dry` | oats | 100 g | 13.2 | 67.7 | 6.5 | 382 | dry weight |
| `rice_cooked` | jasmine rice | 100 g | 2.7 | 28.2 | 0.3 | 126 | cooked weight |
| `sweet_potato` | sweet potato | 100 g | 1.6 | 20.1 | 0.1 | 87 | raw weight |
| `russet_potato` | russet potato | 100 g | 2.1 | 17.5 | 0.1 | 79 | raw weight |

## Protein

| id | name | unit | P | C | F | kcal | note |
|---|---|---|---|---|---|---|---|
| `chicken_raw` | chicken breast | ounce | 6.4 | 0.0 | 0.7 | 32 | boneless skinless, raw weight |
| `beef_93_raw` | 93/7 ground beef | ounce | 5.8 | 0.0 | 2.0 | 41 | raw weight |
| `salmon_raw` | salmon | ounce | 5.8 | 0.0 | 3.8 | 57 | Atlantic, farmed, raw weight |

## Produce

| id | name | unit | P | C | F | kcal | note |
|---|---|---|---|---|---|---|---|
| `blueberries` | blueberries | 100 g | 0.7 | 14.5 | 0.3 | 64 |  |
| `strawberries` | strawberries | 100 g | 0.7 | 7.7 | 0.3 | 36 |  |
| `banana` | banana | each | 1.3 | 27.0 | 0.4 | 117 | medium |
| `broccoli` | broccoli | 100 g | 2.8 | 6.6 | 0.4 | 41 | fresh or frozen |
| `green_beans` | green beans | 100 g | 1.8 | 7.0 | 0.2 | 37 | fresh or frozen |

## Fats

| id | name | unit | P | C | F | kcal | note |
|---|---|---|---|---|---|---|---|
| `olive_oil` | olive oil | tbsp | 0.0 | 0.0 | 13.5 | 122 |  |

## Fast carbs

| id | name | unit | P | C | F | kcal | note |
|---|---|---|---|---|---|---|---|
| `rk_treat` | Rice Krispies treat | each | 0.5 | 17.0 | 2.5 | 92 | original 22 g bar |
| `gatorade_20oz` | Gatorade | bottle | 0.0 | 36.0 | 0.0 | 144 | 20 oz, regular |

## Supplements

| id | name | unit | P | C | F | kcal | note |
|---|---|---|---|---|---|---|---|
| `ghost_vegan` | Ghost vegan protein | scoop | 21.0 | 4.0 | 2.0 | 118 | 33 g scoop, from the label |
| `pbfit` | PBfit | scoop | 8.0 | 5.0 | 1.5 | 66 | 1 serving = 2 tbsp, from the label |
| `collagen` | collagen peptides | scoop | 9.0 | 0.0 | 0.0 | 36 | 10 g scoop |
| `creatine` | creatine | scoop | 0.0 | 0.0 | 0.0 | 0 | 5 g |
| `lmnt` | LMNT | packet | 0.0 | 0.0 | 0.0 | 0 | 1,000 mg sodium |
| `preworkout` | Undefined Pre-Workout V2 | scoop | 0.0 | 0.0 | 0.0 | 0 |  |
| `huel` | Huel Powder | scoop | 14.5 | 18.5 | 6.5 | 190 | v3.1, 50 g scoop, 2 scoops is a 400 kcal meal |
| `huel_black` | Huel Black Edition | scoop | 20.0 | 14.0 | 7.5 | 204 | 45 g scoop, 2 scoops is a 390 kcal meal |
| `huel_rtd` | Huel Ready-to-drink | bottle | 20.0 | 41.0 | 19.0 | 415 | 500 ml bottle, 400 kcal |

## Poultry and meat

| id | name | unit | P | C | F | kcal | note |
|---|---|---|---|---|---|---|---|
| `chicken_thigh_raw` | chicken thigh | ounce | 5.3 | 0.0 | 2.2 | 41 | boneless skinless, raw weight |
| `ground_chicken_raw` | ground chicken | ounce | 5.0 | 0.0 | 2.3 | 41 | raw weight |
| `turkey_breast_raw` | turkey breast | ounce | 6.7 | 0.0 | 0.4 | 30 | skinless, raw weight |
| `turkey_93_raw` | 93/7 ground turkey | ounce | 5.3 | 0.0 | 2.0 | 39 | raw weight |
| `beef_90_raw` | 90/10 ground beef | ounce | 5.7 | 0.0 | 2.8 | 48 | raw weight |
| `beef_80_raw` | 80/20 ground beef | ounce | 4.9 | 0.0 | 5.7 | 71 | raw weight |
| `sirloin_raw` | sirloin steak | ounce | 6.1 | 0.0 | 1.4 | 37 | trimmed, raw weight |
| `flank_raw` | flank steak | ounce | 6.0 | 0.0 | 1.6 | 38 | trimmed, raw weight |
| `pork_loin_raw` | pork loin | ounce | 6.0 | 0.0 | 1.2 | 35 | trimmed, raw weight |
| `pork_tenderloin_raw` | pork tenderloin | ounce | 5.9 | 0.0 | 1.0 | 33 | raw weight |
| `rotisserie_chicken` | rotisserie chicken | ounce | 7.5 | 0.0 | 1.5 | 44 | breast, skin off, cooked weight |
| `deli_turkey` | deli turkey | ounce | 5.0 | 1.0 | 0.5 | 28 | sliced |
| `deli_ham` | deli ham | ounce | 5.0 | 1.0 | 1.5 | 38 | sliced |
| `bacon` | bacon | each | 3.0 | 0.0 | 3.5 | 44 | 1 slice, cooked |
| `turkey_bacon` | turkey bacon | each | 2.5 | 0.3 | 2.0 | 29 | 1 slice, cooked |
| `jerky` | beef jerky | ounce | 9.0 | 6.0 | 1.0 | 69 | typical, check the label |

## Fish

| id | name | unit | P | C | F | kcal | note |
|---|---|---|---|---|---|---|---|
| `cod_raw` | cod | ounce | 5.0 | 0.0 | 0.2 | 22 | raw weight |
| `tilapia_raw` | tilapia | ounce | 5.7 | 0.0 | 0.5 | 27 | raw weight |
| `shrimp_raw` | shrimp | ounce | 5.7 | 0.3 | 0.1 | 25 | peeled, raw weight |
| `tuna_can` | canned tuna | each | 27.0 | 0.0 | 1.0 | 117 | 5 oz can, light, in water, drained |
| `tuna_packet` | tuna packet | each | 17.0 | 0.0 | 0.5 | 72 | 2.6 oz pouch, in water |
| `smoked_salmon` | smoked salmon | ounce | 5.2 | 0.0 | 1.2 | 32 |  |

## Plant protein

| id | name | unit | P | C | F | kcal | note |
|---|---|---|---|---|---|---|---|
| `tofu_firm` | tofu | 100 g | 10.0 | 2.0 | 5.0 | 93 | firm, drained weight |
| `tofu_block` | extra-firm tofu | each | 42.0 | 9.0 | 21.0 | 393 | 14 oz block, pressed |
| `tempeh` | tempeh | 100 g | 20.0 | 8.0 | 11.0 | 211 |  |
| `edamame` | edamame | 100 g | 12.0 | 9.0 | 5.0 | 129 | shelled, cooked |
| `black_beans` | black beans | cup | 15.0 | 41.0 | 0.9 | 232 | cooked |
| `chickpeas` | chickpeas | cup | 14.5 | 45.0 | 4.2 | 276 | cooked |
| `lentils` | lentils | cup | 18.0 | 40.0 | 0.8 | 239 | cooked |
| `hummus` | hummus | tbsp | 1.2 | 3.0 | 1.4 | 29 |  |

## Dairy and eggs

| id | name | unit | P | C | F | kcal | note |
|---|---|---|---|---|---|---|---|
| `greek_yogurt_2` | 2% Greek yogurt | 100 g | 9.5 | 4.0 | 2.0 | 72 | Fage-style |
| `skyr` | skyr | 100 g | 11.0 | 4.0 | 0.2 | 62 | plain, nonfat |
| `cottage_cheese_2` | 2% cottage cheese | 100 g | 11.0 | 4.3 | 2.3 | 82 |  |
| `milk_2` | 2% milk | cup | 8.0 | 12.0 | 5.0 | 125 | 1 cup = 240 ml |
| `milk_skim` | skim milk | cup | 8.0 | 12.0 | 0.2 | 82 | 1 cup = 240 ml |
| `milk_whole` | whole milk | cup | 8.0 | 12.0 | 8.0 | 152 | 1 cup = 240 ml |
| `fairlife_2` | Fairlife 2% milk | cup | 13.0 | 6.0 | 4.5 | 116 | ultra-filtered, 1 cup = 240 ml, from the label |
| `chocolate_milk` | chocolate milk | cup | 8.0 | 26.0 | 2.5 | 158 | low-fat, 1 cup = 240 ml |
| `almond_milk` | almond milk | cup | 1.0 | 1.0 | 2.5 | 30 | unsweetened, 1 cup = 240 ml |
| `cheddar` | cheddar | ounce | 6.8 | 0.9 | 9.4 | 115 |  |
| `mozzarella_ps` | mozzarella | ounce | 6.9 | 0.8 | 4.5 | 71 | part skim |
| `feta` | feta | ounce | 4.0 | 1.1 | 6.0 | 74 |  |
| `parmesan` | parmesan | tbsp | 2.0 | 0.2 | 1.5 | 22 | grated |
| `string_cheese` | string cheese | each | 7.0 | 1.0 | 6.0 | 86 | part-skim stick |
| `cream_cheese` | cream cheese | tbsp | 1.0 | 0.8 | 5.0 | 52 |  |
| `sour_cream` | sour cream | tbsp | 0.4 | 0.6 | 2.5 | 26 |  |
| `heavy_cream` | heavy cream | tbsp | 0.4 | 0.4 | 5.5 | 53 |  |
| `butter` | butter | tbsp | 0.1 | 0.0 | 11.5 | 104 |  |

## Protein powders, shakes and bars

| id | name | unit | P | C | F | kcal | note |
|---|---|---|---|---|---|---|---|
| `whey` | whey protein | scoop | 24.0 | 3.0 | 1.5 | 122 | typical 30 g scoop, check the label |
| `casein` | casein protein | scoop | 24.0 | 3.0 | 1.0 | 117 | typical 33 g scoop, check the label |
| `plant_protein` | plant protein | scoop | 21.0 | 5.0 | 2.0 | 122 | typical pea/rice blend, check the label |
| `premier_shake` | Premier Protein shake | bottle | 30.0 | 4.0 | 3.0 | 163 | 11 oz, from the label |
| `core_power` | Fairlife Core Power | bottle | 26.0 | 8.0 | 3.5 | 168 | 14 oz, from the label (Elite is 42P) |
| `protein_bar` | protein bar | each | 20.0 | 22.0 | 8.0 | 240 | typical 60 g bar, check the label |
| `rxbar` | RXBAR | each | 12.0 | 23.0 | 9.0 | 221 | from the label |

## Grains, starch and bread

| id | name | unit | P | C | F | kcal | note |
|---|---|---|---|---|---|---|---|
| `brown_rice_cooked` | brown rice | 100 g | 2.6 | 23.0 | 0.9 | 110 | cooked weight |
| `quinoa_cooked` | quinoa | 100 g | 4.4 | 21.0 | 1.9 | 119 | cooked weight |
| `couscous_cooked` | couscous | 100 g | 3.8 | 23.0 | 0.2 | 109 | cooked weight |
| `farro_cooked` | farro | 100 g | 6.0 | 26.0 | 1.0 | 137 | cooked weight |
| `pasta_dry` | pasta | 100 g | 13.0 | 75.0 | 1.5 | 366 | dry weight |
| `pasta_cooked` | pasta | 100 g | 5.8 | 31.0 | 0.9 | 155 | cooked weight |
| `cream_of_rice` | cream of rice | 100 g | 6.0 | 86.0 | 0.5 | 372 | dry weight |
| `cream_of_wheat` | cream of wheat | 100 g | 10.0 | 75.0 | 0.5 | 344 | dry weight |
| `grits_dry` | grits | 100 g | 8.5 | 78.0 | 1.2 | 357 | dry weight |
| `kodiak_mix` | Kodiak pancake mix | cup | 28.0 | 60.0 | 4.0 | 388 | dry, from the label, ½ cup is a serving |
| `cheerios` | Cheerios | cup | 3.0 | 20.0 | 2.0 | 110 | typical whole-grain O's |
| `bread_slice` | bread | each | 4.0 | 15.0 | 1.0 | 85 | typical slice, check the label |
| `sourdough_slice` | sourdough | each | 4.0 | 18.0 | 0.5 | 92 | 1 slice, ≈35 g |
| `dkb_slice` | Dave's Killer Bread | each | 5.0 | 22.0 | 1.5 | 122 | 21 Whole Grains, 1 slice |
| `bagel` | bagel | each | 10.0 | 55.0 | 1.5 | 274 | plain, ≈100 g |
| `english_muffin` | English muffin | each | 4.0 | 26.0 | 1.0 | 129 | plain |
| `english_muffin_ww` | whole-wheat English muffin | each | 5.0 | 25.0 | 1.0 | 129 | from the label |
| `pita` | pita | each | 5.5 | 33.0 | 1.0 | 163 | 6-inch |
| `naan` | naan | each | 9.0 | 45.0 | 5.0 | 261 | typical, check the label |
| `tortilla_flour` | flour tortilla | each | 4.0 | 26.0 | 4.0 | 156 | 8 inch |
| `tortilla_corn` | corn tortilla | each | 1.5 | 11.0 | 0.7 | 56 |  |
| `rice_cake` | rice cake | each | 0.7 | 7.0 | 0.3 | 34 | plain |
| `waffle_frozen` | frozen waffle | each | 2.0 | 15.0 | 3.0 | 95 | typical |
| `granola` | granola | 100 g | 10.0 | 64.0 | 15.0 | 431 | typical, check the label |
| `pretzels` | pretzels | ounce | 3.0 | 23.0 | 1.0 | 113 |  |
| `tortilla_chips` | tortilla chips | ounce | 2.0 | 19.0 | 7.0 | 147 |  |
| `popcorn` | popcorn | cup | 1.0 | 6.0 | 0.4 | 32 | air-popped |
| `corn` | corn | cup | 5.4 | 41.0 | 2.4 | 207 | kernels, cooked |
| `sweet_corn` | sweet corn | 100 g | 3.0 | 20.0 | 0.8 | 99 | kernels, frozen |
| `peas` | peas | cup | 8.6 | 25.0 | 0.4 | 138 | cooked |

## Fruit

| id | name | unit | P | C | F | kcal | note |
|---|---|---|---|---|---|---|---|
| `apple` | apple | each | 0.5 | 25.0 | 0.3 | 105 | medium |
| `pear` | pear | each | 0.6 | 27.0 | 0.2 | 112 | medium |
| `orange` | orange | each | 1.2 | 15.0 | 0.2 | 67 | medium |
| `clementine` | clementine | each | 0.6 | 9.0 | 0.1 | 39 |  |
| `peach` | peach | each | 1.4 | 14.0 | 0.4 | 65 | medium |
| `plum` | plum | each | 0.5 | 8.0 | 0.2 | 36 |  |
| `kiwi` | kiwi | each | 0.8 | 10.0 | 0.4 | 47 |  |
| `dates` | medjool date | each | 0.4 | 18.0 | 0.0 | 74 | pitted |
| `grapes` | grapes | 100 g | 0.7 | 18.0 | 0.2 | 77 |  |
| `cherries` | cherries | 100 g | 1.1 | 16.0 | 0.2 | 70 | pitted |
| `raspberries` | raspberries | 100 g | 1.2 | 12.0 | 0.7 | 59 |  |
| `blackberries` | blackberries | 100 g | 1.4 | 9.6 | 0.5 | 48 |  |
| `mixed_berries` | mixed berries | 100 g | 0.7 | 12.0 | 0.3 | 54 | frozen |
| `pineapple` | pineapple | 100 g | 0.5 | 13.0 | 0.1 | 55 |  |
| `mango` | mango | 100 g | 0.8 | 15.0 | 0.4 | 67 |  |
| `watermelon` | watermelon | 100 g | 0.6 | 7.6 | 0.2 | 35 |  |
| `raisins` | raisins | 100 g | 3.0 | 79.0 | 0.5 | 332 |  |
| `applesauce` | applesauce | cup | 0.4 | 27.0 | 0.2 | 111 | unsweetened, 1 cup = 240 ml |
| `orange_juice` | orange juice | cup | 1.7 | 26.0 | 0.5 | 115 | 1 cup = 240 ml |
| `coconut_water` | coconut water | cup | 2.0 | 9.0 | 0.5 | 48 | 1 cup = 240 ml |

## Vegetables

| id | name | unit | P | C | F | kcal | note |
|---|---|---|---|---|---|---|---|
| `spinach` | spinach | 100 g | 2.9 | 3.6 | 0.4 | 30 | raw |
| `kale` | kale | 100 g | 2.9 | 4.4 | 1.5 | 43 | raw |
| `mixed_greens` | mixed greens | 100 g | 1.5 | 3.0 | 0.2 | 20 | salad mix |
| `romaine` | romaine lettuce | 100 g | 1.2 | 3.3 | 0.3 | 21 |  |
| `asparagus` | asparagus | 100 g | 2.2 | 3.9 | 0.1 | 25 |  |
| `bell_pepper` | bell pepper | 100 g | 1.0 | 6.0 | 0.3 | 31 |  |
| `pepper_onion_strips` | pepper & onion strips | 100 g | 1.5 | 6.0 | 0.2 | 32 | frozen |
| `stir_fry_veg` | stir-fry vegetables | 100 g | 2.0 | 7.0 | 0.3 | 39 | frozen Asian mix |
| `mixed_veg` | mixed vegetables | 100 g | 2.6 | 12.0 | 0.3 | 61 | frozen, peas-carrots-corn-beans |
| `zucchini` | zucchini | 100 g | 1.2 | 3.1 | 0.3 | 20 |  |
| `butternut` | butternut squash | 100 g | 1.0 | 12.0 | 0.1 | 53 | raw |
| `carrots` | carrots | 100 g | 0.9 | 9.6 | 0.2 | 44 |  |
| `beets` | beets | 100 g | 1.6 | 10.0 | 0.2 | 48 |  |
| `celery` | celery | 100 g | 0.7 | 3.0 | 0.2 | 17 |  |
| `cauliflower` | cauliflower | 100 g | 1.9 | 5.0 | 0.3 | 30 |  |
| `brussels` | Brussels sprouts | 100 g | 3.4 | 9.0 | 0.3 | 52 |  |
| `snap_peas` | sugar snap peas | 100 g | 2.8 | 7.6 | 0.2 | 43 |  |
| `cucumber` | cucumber | 100 g | 0.7 | 3.6 | 0.1 | 18 |  |
| `tomato` | tomato | 100 g | 0.9 | 3.9 | 0.2 | 21 |  |
| `onion` | onion | 100 g | 1.1 | 9.3 | 0.1 | 42 |  |
| `mushrooms` | mushrooms | 100 g | 3.1 | 3.3 | 0.3 | 28 |  |
| `cabbage` | cabbage | 100 g | 1.3 | 5.8 | 0.1 | 29 |  |
| `kalamata` | kalamata olive | each | 0.0 | 0.2 | 0.6 | 6 | pitted, ≈4 g each, 8 olives ≈ 30 g |

## Fats, nuts and seeds

| id | name | unit | P | C | F | kcal | note |
|---|---|---|---|---|---|---|---|
| `avocado` | avocado | each | 3.0 | 13.0 | 22.0 | 262 | medium, ≈150 g flesh |
| `guacamole` | guacamole | tbsp | 0.3 | 1.0 | 2.0 | 23 |  |
| `peanut_butter` | peanut butter | tbsp | 3.6 | 3.1 | 8.1 | 100 |  |
| `almond_butter` | almond butter | tbsp | 3.4 | 3.0 | 9.0 | 107 |  |
| `tahini` | tahini | tbsp | 2.6 | 3.0 | 8.0 | 94 |  |
| `almonds` | almonds | 100 g | 21.0 | 22.0 | 50.0 | 622 |  |
| `walnuts` | walnuts | 100 g | 15.0 | 14.0 | 65.0 | 701 |  |
| `cashews` | cashews | 100 g | 18.0 | 30.0 | 44.0 | 588 |  |
| `peanuts` | peanuts | 100 g | 26.0 | 16.0 | 49.0 | 609 |  |
| `pistachios` | pistachios | 100 g | 20.0 | 28.0 | 45.0 | 597 | shelled |
| `sunflower_seeds` | sunflower seeds | 100 g | 21.0 | 20.0 | 51.0 | 623 | shelled |
| `chia` | chia seeds | tbsp | 2.0 | 5.0 | 4.0 | 64 |  |
| `flax` | ground flaxseed | tbsp | 1.3 | 2.0 | 3.0 | 40 |  |
| `avocado_oil` | avocado oil | tbsp | 0.0 | 0.0 | 14.0 | 126 |  |
| `coconut_oil` | coconut oil | tbsp | 0.0 | 0.0 | 14.0 | 126 |  |
| `sesame_oil` | sesame oil | tsp | 0.0 | 0.0 | 4.5 | 40 |  |
| `mayo` | mayonnaise | tbsp | 0.0 | 0.0 | 10.0 | 90 |  |
| `light_mayo` | light mayonnaise | tbsp | 0.0 | 1.0 | 3.5 | 36 |  |
| `ranch` | ranch dressing | tbsp | 0.0 | 1.0 | 7.0 | 67 |  |
| `pesto` | pesto | tbsp | 1.0 | 1.0 | 8.0 | 80 |  |
| `coconut_milk` | coconut milk | cup | 4.0 | 8.0 | 48.0 | 480 | canned, full fat, 1 cup = 240 ml, ¼ cup is a serving |
| `dark_chocolate` | dark chocolate | 100 g | 7.8 | 46.0 | 43.0 | 602 | 70–85% |

## Sweet and sauces

| id | name | unit | P | C | F | kcal | note |
|---|---|---|---|---|---|---|---|
| `honey` | honey | tbsp | 0.0 | 17.0 | 0.0 | 68 |  |
| `maple_syrup` | maple syrup | tbsp | 0.0 | 13.0 | 0.0 | 52 |  |
| `sugar` | sugar | tsp | 0.0 | 4.0 | 0.0 | 16 |  |
| `jam` | jam | tbsp | 0.0 | 13.0 | 0.0 | 52 |  |
| `nutella` | Nutella | tbsp | 1.0 | 11.0 | 6.0 | 102 | from the label |
| `ketchup` | ketchup | tbsp | 0.2 | 4.5 | 0.0 | 19 |  |
| `bbq_sauce` | BBQ sauce | tbsp | 0.2 | 7.0 | 0.0 | 29 | typical, check the label |
| `salsa` | salsa | tbsp | 0.2 | 1.0 | 0.0 | 5 |  |
| `marinara` | marinara | cup | 4.0 | 20.0 | 4.0 | 132 | jarred, typical, ½ cup is a serving |
| `teriyaki` | teriyaki sauce | tbsp | 0.1 | 3.0 | 0.0 | 13 | marinade-style, 15 g a tbsp, glazes run 2–3× the carbs, check the label |
| `soy_sauce` | soy sauce | tbsp | 1.3 | 1.0 | 0.0 | 9 |  |
| `hoisin` | hoisin sauce | tbsp | 0.6 | 7.0 | 0.5 | 35 |  |
| `sriracha` | sriracha | tsp | 0.0 | 1.0 | 0.0 | 4 |  |
| `balsamic` | balsamic vinegar | tbsp | 0.0 | 3.0 | 0.0 | 12 |  |
| `tzatziki` | tzatziki | 100 g | 10.0 | 5.0 | 0.5 | 65 | made on 0% Fage |
| `cornstarch` | cornstarch | tbsp | 0.0 | 7.0 | 0.0 | 28 | the crispy coating |

## Eating out

| id | name | unit | P | C | F | kcal | note |
|---|---|---|---|---|---|---|---|
| `chipotle_chicken` | Chipotle chicken | each | 32.0 | 0.0 | 7.0 | 191 | 1 scoop, 4 oz |
| `chipotle_steak` | Chipotle steak | each | 21.0 | 1.0 | 6.0 | 142 | 1 scoop, 4 oz |
| `chipotle_sofritas` | Chipotle sofritas | each | 8.0 | 9.0 | 10.0 | 158 | 1 scoop, 4 oz |
| `chipotle_white_rice` | Chipotle white rice | each | 4.0 | 40.0 | 4.0 | 212 | 1 scoop, 4 oz |
| `chipotle_brown_rice` | Chipotle brown rice | each | 4.0 | 36.0 | 6.0 | 214 | 1 scoop, 4 oz |
| `chipotle_black_beans` | Chipotle black beans | each | 8.0 | 22.0 | 1.5 | 134 | 1 scoop, 4 oz |
| `chipotle_pinto_beans` | Chipotle pinto beans | each | 8.0 | 21.0 | 1.5 | 130 | 1 scoop, 4 oz |
| `chipotle_fajita_veg` | Chipotle fajita veggies | each | 1.0 | 5.0 | 0.0 | 24 | 1 scoop |
| `chipotle_corn_salsa` | Chipotle corn salsa | each | 3.0 | 16.0 | 1.5 | 90 | 1 scoop |
| `chipotle_tomato_salsa` | Chipotle tomato salsa | each | 0.0 | 4.0 | 0.0 | 16 | 1 scoop |
| `chipotle_guac` | Chipotle guacamole | each | 2.0 | 8.0 | 22.0 | 238 | 1 scoop, 4 oz |
| `chipotle_cheese` | Chipotle cheese | each | 6.0 | 1.0 | 8.0 | 100 | 1 scoop |
| `chipotle_sour_cream` | Chipotle sour cream | each | 2.0 | 2.0 | 9.0 | 97 | 1 scoop |

Gram ingredients are shown per 100 g for readability; `per` in pantry.json and in the app is per gram.
